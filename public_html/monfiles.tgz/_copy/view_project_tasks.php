<?php
	include("./includes/date_functions.php");
	include("./includes/common.php");
	
	CheckSecurity(1);
	
	$T = new iTemplate($sAppPath);
	$T->set_file("main","view_project_tasks.html");
	
	$sort = GetParam("sort");
	$close_tasks = GetParam("close_tasks");
	$project_id = GetParam("project_id");
	
	/**/
	if ((getsessionparam("privilege_id") == 9)||(!isset($project_id))) {
		header("Location: index.php");
		exit;
	}
	/**/

	$db2 = new DB_Sql;
	$db2->Database = DATABASE_NAME;
	$db2->User     = DATABASE_USER;
	$db2->Password = DATABASE_PASSWORD;
	$db2->Host     = DATABASE_HOST;

	$sql = 'SELECT * FROM projects p, tasks t WHERE t.project_id=p.project_id AND p.project_id='.ToSQL($project_id,"integer");
	$db->query($sql,__FILE__,__LINE__);
	$db->next_record();
	$T->set_var('project_title', $db->Record['project_title']);
	$T->set_var('project_id', $db->Record['project_id']);
	$parent_project_id = $db->f("parent_project_id");
	$current_status_id = $db->f("project_status_id");
	
	get_select_options("projects_statuses", "project_status_id", "status_desc", $current_status_id,
			"WHERE parent_project_id=".ToSQL($parent_project_id, "integer"), 
			"status_order ASC", "", "", "project_status_id", array("0"=>"-- please select status --"));
	
	$T->set_var("assigned_users","");
	$sql  = " SELECT concat(u.first_name, ' ', u.last_name) as user";
	$sql .= " FROM users_projects up LEFT JOIN users u ON (up.user_id=u.user_id)";
	$sql .= " WHERE up.project_id=".ToSQL($project_id,"integer");
	$sql .= " ORDER BY u.first_name";
	$db->query($sql);
	if ($db->next_record())
	{
		do {
			$T->set_var("assigned_user", $db->f("user"));
			$T->parse("assigned_users", true);
		} while ($db->next_record());
	}
	
	$sql  = "SELECT * FROM tasks WHERE project_id=".ToSQL($project_id,"integer");
	if (!$close_tasks) {
		$sql .= " AND is_closed=0 ";
	} else {
		$T->set_var("close_tasks_checked","CHECKED");
	}
	$db->query($sql,__FILE__,__LINE__);

	$statuses_classes = array(
		"",
		"InProgress",
		"OnHold",
		"Rejected",
		"Done",
		"Question",
		"Answer",
		"New",
		"Waiting",
		"Reassigned",
		"Bug",
		"Deadline",
		"BugResolved",
		"ReadyToDocument",
		"Documented"
		);
	
	$T->parse("records_header",false);

	$i=0;
	$Total_time = 0;
	if  ($db->next_record()) {
		do{
			$list[$i]['task_title']= $db->Record['task_title'];
			//get responsible person
			$sql2 = 'SELECT u.user_id, CONCAT(u.first_name, \' \', u.last_name)as name FROM users u, tasks t
						WHERE u.user_id=t.responsible_user_id AND task_id='.$db->Record['task_id'];
			$db2->query($sql2,__FILE__,__LINE__);
			$db2->next_record();
			$list[$i]['responsible_id']= $db2->Record['user_id'];
			$list[$i]['responsible']= $db2->Record['name'];

			//get created person
			$sql2 = 'SELECT u.user_id, CONCAT(u.first_name, \' \', u.last_name)as name FROM users u, tasks t
						WHERE u.user_id=t.created_person_id AND task_id='.$db->Record['task_id'];
			$db2->query($sql2,__FILE__,__LINE__);
			$db2->next_record();
			$list[$i]['created_id']= $db2->Record['user_id'];
			$list[$i]['created']= $db2->Record['name'];

			//get spent hours
			$sql2 = "SELECT SUM(spent_hours) as spent FROM time_report WHERE task_id=".$db->Record['task_id']." GROUP BY task_id";
			$db2->query($sql2,__FILE__,__LINE__);
			$db2->next_record();

			$list[$i]['spent_hours']= Hours2HoursMins($db2->Record['spent']);
			$Total_time += $db2->Record['spent'];
			$list[$i]['task_id']= $db->Record['task_id'];

			$sql2  = " SELECT planed_date, completion ";
			$sql2 .= " , IF(DATE(NOW())>DATE(planed_date) AND planed_date<>'0000-00-00', '#F6B0B0', '#F6FABE') as color ";
			$sql2 .= " FROM tasks WHERE task_id=".$db->Record['task_id'];
			$db2->query($sql2,__FILE__,__LINE__);
			$db2->next_record();
			$list[$i]['completion']= $db2->Record['completion'];
			$list[$i]['planed_date']= $db2->Record['planed_date'];
			$list[$i]['color']= $db2->Record['color'];
			$list[$i]['STATUS']= $statuses_classes[$db->Record["task_status_id"]];
			$list[$i]['is_closed'] = $db->f("is_closed");
			$i++;
		}while($db->next_record());
	}
	else{
		$T->set_var("records", "");
		$T->set_var("records_footer", "");
		$T->parse('no_records', false);
	}

	if (isset($list)){
		$T->set_var("no_records", "");
		usort($list, 'compare_by_keys');
		foreach ($list as $v) {			
			$T->set_var('task_title', $v['task_title']);
			$T->set_var('responsible_id', $v['responsible_id']);
			$T->set_var('responsible', $v['responsible']);
			$T->set_var('created', $v['created']);
			$T->set_var('created_id', $v['created_id']);
			$T->set_var('spent_hours', $v['spent_hours']);
			$T->set_var('completion', $v['completion']);
			$T->set_var('planed_date', $v['planed_date']);
			//$T->set_var('deadline_color', (isset($v['deadline_color'])?$v['deadline_color']:""));
			$T->set_var('task_id', $v['task_id']);
			$T->set_var('color', $v['color']);
			$T->set_var("STATUS", $v['STATUS']);
			$T->set_var("is_closed",($v['is_closed']?"YES":"NO"));
			$T->parse('records', true);
		}
		if ($Total_time>0) {
			$Total_time = Hours2HoursMins($Total_time);
		}
		$T->set_var("total_time",$Total_time);
		$T->parse("records_footer",false);
	}

	$T->pparse("main");

function compare_by_keys($a, $b){
	global $sort;
	switch ($sort){
		case 'by_title':$k='task_title';break;
		case 'by_responsible':$k='responsible';break;
		case 'by_created':$k='created';break;
 		case 'by_hours':$k='spent_hours';break;
		case 'by_planed_date':$k='planed_date';break;
		case 'by_completion':$k='completion';break;
		default:$k='task_id';;
	}
    if (($k == 'task_title') || ($k == 'responsible') || ($k == 'created')) {
		if (strtolower($a[$k])>strtolower($b[$k])) return 1;

			else return 0;
    }
    else
    {
    	if ($a[$k]<$b[$k]) return 1;

		else return 0;

    }

}
?>