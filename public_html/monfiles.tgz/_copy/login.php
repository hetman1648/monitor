<?php

include ("./includes/common.php");



$sFileName = "login.php";
$sTemplateFileName = "login.html";

$T= new iTemplate($sAppPath,array("main"=>$sTemplateFileName));
$T->set_var("FileName", $sFileName);

$sFormErr = "";

$sAction = GetParam("FormAction");
$sForm = GetParam("FormName");

//-- check for 'remembered' in cookies login
$r_login = ""; $r_password = ""; $remembered_login = false;
if (isset($HTTP_COOKIE_VARS["monitor_login"])) {
	if ($HTTP_COOKIE_VARS["monitor_login"] && $sAction!=="logout")
	{
	  $login_array = explode("|",$HTTP_COOKIE_VARS["monitor_login"]);
	  if ($login_array[0] && $login_array[1])
	  {
	    $remembered_login = true;
	    $r_login    = $login_array[0];
	    $r_password = $login_array[1];      
	    $sAction  = "login";
	  }
	}
}

FormAction($sAction);
Form_Show();

$T->parse("main", false);
echo $T->p("main");


function FormAction($sAction)
{
  global $db;
  global $T;
  global $sFormErr;
  global $remember_me;
  global $r_login;
  global $r_password;
  global $remembered_login;
  global $perms;

  switch(strtolower($sAction))
  {
    case "login":
      if ($remembered_login)
      {
        $sLogin = $r_login;
        $sPassword = $r_password;
      }
      else
      {
        $sLogin = GetParam("Login");
        $sPassword = GetParam("Password");
      }

      $sql  = " SELECT * FROM (users u";
      $sql .= " LEFT JOIN lookup_users_privileges p ON u.privilege_id=p.privilege_id)";
      $sql .= " WHERE login ='" . $sLogin . "' AND password='" . $sPassword . "' ";
      $sql .= " AND p.PERM_LOGIN_INTERNAL_MONITOR=1";
      $sql .= " AND u.is_deleted IS NULL";
      $db->query($sql);
      if($db->next_record())
      {
        header("Cache-Control: public"); 
	//header("Age: 699");
		foreach($perms AS $key=>$value)
		{
			$perms[$key] = $db->Record[$key];
			//echo "$key-" . $perms[$key]."<br>";
		}	
		//exit;

        SetSessionParam("UserID", $db->f("user_id"));
        SetSessionParam("privilege_id", $db->f("privilege_id"));
        SetSessionParam("UserName", $db->f("first_name")." ".$db->f("last_name"));
        SetSessionParam("session_perms", $perms);

        if ($remember_me) setcookie("monitor_login",$sLogin."|".$sPassword,time()+3600*24*365);

        $sPage = GetParam("ret_page");
        if (strlen($sPage))
          header("Location: " . $sPage);
        else
          header("Location: index.php");
      }
      else
      {
        $sFormErr = "Login or Password is incorrect";
      }

      $T->parse("FormForm", false);
    break;
    case "logout":
      session_unregister("UserID");
      session_unregister("privilege_id");
      session_unregister("UserName");
      session_unregister("session_perms");
      
      setcookie("monitor_login","");

      $T->parse("FormForm", false);
    break;
  }
}

function Form_Show()
{
  global $T;
  global $sFormErr;
  global $db;

  $T->set_var("sFormErr", $sFormErr);
  $T->set_var("querystring", GetParam("querystring"));
  $T->set_var("ret_page", GetParam("ret_page"));
  if(GetSessionParam("UserID") == "") 
  {
    $T->set_var("LogoutAct", "");
    $T->set_var("UserInd", "");
    if($sFormErr == "")
      $T->set_var("FormError", "");
    else
    {
      $T->set_var("sFormErr", $sFormErr);
      $T->parse("FormError", false);
    }
    $T->parse("LoginAct", false);
  }
  else
  {
    $db->query("SELECT login FROM users WHERE user_id=". GetSessionParam("UserID"));
    $db->next_record();
    $T->set_var("FormError", "");
    $T->set_var("LoginAct", "");
    $T->set_var("UserID", $db->f("login"));
    $T->parse("UserInd", false);
  }
  $T->parse("FormForm", false);
}

?>