<?php
	include ("./includes/common.php");
	
	$t = new iTemplate($sAppPath);
	$t->set_file("main", "ajax_responder.html");
	
	switch (GetParam("action")) {
		case "get_domains_list":
			get_domains_list(GetParam("domain"));
		break;
		case "get_clients_list":
			get_clients_list(GetParam("client"),(int) GetParam("task_id"));
		break;
		case "task_update_client":
			task_update_client((int) GetParam("client_id"),(int) GetParam("task_id"));
		break;
		case "get_tasks_list":
			get_tasks_list((int) GetParam("user_id"));
		break;
	}
		
	function get_domains_list($domain) {
		global $db, $t;
		
		$domain = strtolower(trim(rtrim($domain)));
		if (strpos($domain, "www.") === 0) {
			$domain = substr($domain, 4);
		}
		$t->set_var("search_domain", $domain);
		
		$sql  = " SELECT d.domain_id, d.domain_url, c.client_id, c.client_name FROM tasks_domains AS d ";
		$sql .= " LEFT JOIN clients AS c ON c.client_id=d.client_id ";
		$sql .= " WHERE d.domain_url LIKE '" . ToSQL($domain, "text", false, false) . "%'";
		$sql .= " OR d.domain_url LIKE 'www." . ToSQL($domain, "text", false, false) . "%'";
		$sql .= " ORDER BY d.domain_url";
		$db->query($sql);
		if ($db->next_record()) {
			$t->set_var("no_domain", "");
			do {
				$t->set_var("domain_id",   $db->f("domain_id"));
				$t->set_var("domain_url",  $db->f("domain_url"));
				$t->set_var("client_id",   $db->f("client_id"));
				$t->set_var("client_name", $db->f("client_name"));
				$t->parse("domain");
			} while ($db->next_record());
		} else {
			$t->set_var("domain", "");
			$t->parse("no_domain");
		}
		$t->parse("domains");
		echo $t->get_var("domains");		
	}
	
	function get_clients_list($client, $task_id) {
		global $db, $t;
		
		$client = strtolower(trim(rtrim($client)));
		$t->set_var("search_client", $client);
		
		$sql  = " SELECT client_id, client_company FROM clients";
		$sql .= " WHERE client_name LIKE '%" . ToSQL($client, "text", false, false) . "%'";
		$sql .= " OR client_company LIKE '%" . ToSQL($client, "text", false, false) . "%'";
		$sql .= " OR client_email LIKE '%"   . ToSQL($client, "text", false, false) . "%'";
		if (is_numeric($client)) {
			$sql .= " OR client_id="    . ToSQL($client, "integer");
			$sql .= " OR sayu_user_id=" . ToSQL($client, "integer"); 
		}
		$sql .= " ORDER BY client_company";
		$db->query($sql);
		if ($db->next_record()) {
			$t->set_var("no_client", "");
			do {
				$client_id  = $db->f("client_id");
				$client_name = $db->f("client_company");
				if (strlen($client_name)>0)
				{
					$t->set_var("client_id",  $client_id);
					$t->set_var("task_id",  $task_id);
					$t->set_var("client_name", $client_name);
					$t->parse("client");
				}
			} while ($db->next_record());
		} else {
			$t->set_var("client", "");
			$t->parse("no_client");
		}
		$t->parse("clients");
		echo $t->get_var("clients");		
	}
	
	function task_update_client($client_id,$task_id)
	{
		global $db;
		
		$sql = "UPDATE tasks SET client_id=".ToSQL($client_id, "integer");
		$sql .= " WHERE task_id=".ToSQL($task_id, "integer");
		$db->query($sql);
	}
		
	function get_tasks_list($responsible_user_id) {
		global $db, $t;
			
		$statuses_classes = array("","InProgress","OnHold","Rejected","Done","Question","Answer","New","Waiting","Reassigned","Bug","Deadline",
		"BugResolved", "Documented", "ReadyToDocument", "New", "New", "New", "New", "New", "New", "New");

		$operation = GetParam("operation");
		$move_task_id    = 0;
		$move_task_index = -1;
		if ($operation) {
			if ($operation == "move") {
				$move_task_id = (int) GetParam("task_id");
				$move_dir     = GetParam("dir");
			}
		}
		
		// select tasks list
		$i = 0; $prev_priority_id = 0;
		$tasks = array();				
		$sql  = " SELECT t.*, ";
		$sql .= " IF(t.task_status_id=2, 1, 0) AS sorter, ";
		$sql .= " IF (TO_DAYS(t.planed_date) < TO_DAYS(now()) AND t.task_status_id!=4 AND t.task_type_id!=3,1,0 ) AS ifdeadlined, ";
		$sql .= " IF (TO_DAYS(t.planed_date) = TO_DAYS(now()) AND t.task_status_id!=4 AND t.task_type_id!=3,1,0 ) AS iftoday, ";  	
		$sql .= " p.project_title FROM (tasks t ";
		$sql .= " LEFT JOIN projects p ON p.project_id = t.project_id) ";
		$sql .= " WHERE t.responsible_user_id=" . ToSQL($responsible_user_id, "integer");
		$sql .= " AND t.is_closed=0 AND t.is_wish=0 AND t.task_type_id<>3 ";			
		$sql .= " ORDER BY sorter, t.priority_id";		
		$db->query($sql);
		while($db->next_record()) {
			$task_id = $db->f("task_id");
			if ($move_task_id == $task_id) {
				$move_task_index = $i;
			}
			$priority_id = $db->f("priority_id");
			if ($priority_id <= $prev_priority_id) {
				$priority_id = $prev_priority_id+1;
			}
			$prev_priority_id = $priority_id;
			
			$task_title = ToHTML($db->f("task_title"));
			$status_id  = $db->f("task_status_id");
			if ($db->f("iftoday")) {
				if ($status_id !=1) $style = "Today";
			} elseif ($db->f("ifdeadlined")) {
				$task_title = "<font color=\"red\"><b>" . $task_title . "</b></font>";
				if ($status_id !=1) $style = "Deadline";
			} else {
				$style     = $statuses_classes[$status_id];
				if ($i%2) {	$style .=2;	}
			}
			
			
			$tasks[$i] = array(
				"task_id"       => $task_id,
				"task_title"    => $task_title,
				"priority_id"   => $priority_id,
				"project_title" => ToHTML($db->f("project_title")),
				"style"         => $style
			);
			$i++;
		}
		
		if ($operation == "move" && $move_task_index >= 0) {
			$move_task_index_2 = (($move_dir < 0) ? 1 : -1) * 1 + $move_task_index;			
			if (isset($tasks[$move_task_index]) && isset($tasks[$move_task_index_2])) {				
				$tasks[$move_task_index]["style"] = $tasks[$move_task_index]["style"] . " DataRow3";								
				$tmp                              = $tasks[$move_task_index_2];
				$tasks[$move_task_index_2]        = $tasks[$move_task_index];
				$tasks[$move_task_index]          = $tmp;				
				$tasks[$move_task_index]["priority_id"]   = $tasks[$move_task_index_2]["priority_id"];
				$tasks[$move_task_index_2]["priority_id"] = $tmp["priority_id"];
				
				$tasks[$move_task_index]["style"] = $tasks[$move_task_index]["style"] . " DataRow3";
				
				foreach ($tasks AS $task) {
					$sql  = " UPDATE tasks SET priority_id=" . $task["priority_id"];
					$sql .= " WHERE task_id=" . $task["task_id"];	
					$db->query($sql);	
				}
			}
		}
		
		$i = 0;
		if ($tasks) {
			$t->set_var("no_task", "");
			$prev_project_title = "";
			foreach ($tasks AS $task) {
				$task_id       = $task["task_id"];
				$task_title    = $task["task_title"];
				$priority_id   = $task["priority_id"];
				$project_title = $task["project_title"];
				$style         = $task["style"];
				$t->set_var("task_id",       $task_id);
				$t->set_var("task_title",    $task_title);			
				$t->set_var("priority_id",   $priority_id);
				if ($project_title != $prev_project_title) {
					$prev_project_title = $project_title;
					$t->set_var("project_title", $project_title);
				} else {
					$t->set_var("project_title_cutted", "");
				}
				$t->set_var("task_class", $style);
				$t->parse("task");
				$i++;
			};
		} else {
			$t->set_var("task", "");
			$t->parse("no_task");
		}
		
		$t->parse("tasks");
		echo $t->get_var("tasks");
	}
?>