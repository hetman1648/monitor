<?php
	include("./includes/date_functions.php");
	include("./includes/common.php");

	CheckSecurity(1);

	$filter_parent_project_id = GetParam("filter_parent_project_id");
	
	$post_vars = get_post_vars();
	if(sizeof($post_vars)) {		
		foreach($post_vars as $key=>$value) {
			
			if (strpos($key, "project_status_id_")===0) {
				$project_id = substr($key, 18);
				$sql = "UPDATE projects SET project_status_id=".ToSQL($value, "integer", false)." WHERE project_id=".ToSQL($project_id, "number");
				$db->query($sql);				
			}
		}
		
		$return_page = "projects_summary.php";
		if ($filter_parent_project_id) {
			$return_page.="?filter_parent_project_id=".$filter_parent_project_id;
		}
		header("Location: ".$return_page);
		exit;
	}
	
	$project_statuses = array();
	$sql = " SELECT parent_project_id, project_status_id, status_desc, color ";
	$sql.= " FROM projects_statuses ";
	if ($filter_parent_project_id) {
		$sql.= " WHERE parent_project_id=".ToSQL($filter_parent_project_id, "integer");
	}
	$sql.= " ORDER BY parent_project_id, status_order, status_desc, project_status_id ";
	$db->query($sql);
	while($db->next_record()) {
		$parent_project_id = $db->f("parent_project_id");
		if (!isset($project_statuses[$parent_project_id])) {
			$project_statuses[$parent_project_id][0] = array("key"=>"0", "value"=>"-- please select status --", "color"=>"black");
		}
		$project_statuses[$parent_project_id][] = array("key"=>$db->f("project_status_id"), "value"=>$db->f("status_desc"), "color"=>$db->f("color"));
	}

	$T = new iTemplate($sAppPath);
	$T->set_file("main","projects_summary.html");
	
	get_select_options("projects", "project_id", "project_title", $filter_parent_project_id, "WHERE parent_project_id IS NULL AND is_closed=0",
	 "project_title", "", "", "parent_project_id", array("0"=>"-- show all projects --"));
	
	//get projects
	$sql = " SELECT parent.project_id,
  				 parent.project_title,
  				 parent.project_status_id,
  				 parent.is_closed,
				 child.project_id AS c_id,
				 child.project_title AS c_title,
				 child.project_status_id AS c_status_id,
				 child.is_closed AS c_closed,
				 COUNT(DISTINCT(t.task_id)) AS tasks,
				 ROUND(SUM(tr.spent_hours),2) AS hours,				 
				 COUNT(DISTINCT(tr.user_id)) AS people,
				 IF(child.is_closed=0 AND ps_exist.project_status_id IS NOT NULL, 1, 0) AS allow_select,
				 IF(child.is_closed=0, child.project_status_id, 0) AS child_status_id,
				 IF(child.is_closed=0, ps.status_desc, 'Closed') AS child_status_desc,
				 IF(child.is_closed=0, IF(ps.color!='' AND ps.color IS NOT NULL, ps.color, 'black'), '#D0D0D0') AS child_color

		FROM projects AS parent
		 	  INNER JOIN projects AS child ON (parent.project_id=child.parent_project_id)		 	  
		 	  LEFT JOIN tasks t ON (child.project_id = t.project_id)
		 	  LEFT JOIN time_report tr ON (t.task_id = tr.task_id)
		 	  LEFT JOIN projects_statuses AS ps ON (ps.project_status_id=child.project_status_id)
		 	  LEFT JOIN projects_statuses AS ps_exist ON (ps_exist.parent_project_id=parent.project_id)

		 WHERE parent.parent_project_id IS NULL AND parent.is_closed=0 ";
	if ($filter_parent_project_id>0) {
		$sql.= " AND parent.project_id=".ToSQL($filter_parent_project_id, "integer");
	}
	$sql.= "
		 GROUP BY parent.project_id, child.project_id
		 ORDER BY is_closed,
		 		  parent.project_title,
		 		  child.is_closed,
		 		  child.project_title ";
	
	$db->query($sql);
	
	$parent_project_id = 0;
	while ($db->next_record()) {
		$T->set_var($db->Record);
		if ($parent_project_id != $db->f("project_id") || !$parent_project_id) {
			$T->parse("parent_project", false);
		} else {
			$T->set_var("parent_project", "");
		}
		$parent_project_id = $db->f("project_id");
		
		if (isset($project_statuses[$db->f("project_id")])) {
			get_select_options_array($project_statuses[$db->f("project_id")], $db->f("child_status_id"), "project_status_id");
		}
		if ($db->f("allow_select")) {
			$T->parse("project_status_select" ,false);
			$T->set_var("child_status_desc" ,"");
		} else {
			$T->set_var("project_status_select" ,"");
		}		
		$T->parse("project", true);
	}	
	$T->set_var("filter_parent_project_id", $filter_parent_project_id);
	
	$T->pparse("main");
?>