<?php

	include("./includes/date_functions.php");
	include("./includes/common.php");

	$t = new iTemplate($sAppPath);
	$t->set_file("main","time_report.html");
	
	$default_period = 1;

	include("./filter.php");

	CheckSecurity(1);

	if (getsessionparam("privilege_id") == 9) {
		header("Location: index.php");
		exit;
	}
	
	if ($submit) {
		$sql = " SELECT CONCAT(u.first_name, ' ', u.last_name) as person, t.task_title, tr.task_id, tr.spent_hours, ";
		$sql .= " DATE_FORMAT(tr.started_date, '%d %b %Y - %W') AS date, DATE_FORMAT(tr.report_date, '%d %b %Y - %W') AS rdate, ";
		$sql .= " UNIX_TIMESTAMP(tr.started_date) as start_time_u, UNIX_TIMESTAMP(tr.report_date) as end_time_u ";
		$sql .= " FROM users u, time_report tr, tasks t ";
		$sql .= " WHERE u.user_id=tr.user_id AND t.task_id=tr.task_id ".$sqlteam;
		if ($person_selected) $sql .= " AND tr.user_id=" . ToSQL($person_selected, "integer");
		if ($sdt) $sql .= " AND tr.started_date>='$sdt' ";
		if ($edt) $sql .= " AND tr.started_date<='$edt' ";
		$sql .= " ORDER BY TO_DAYS(tr.started_date), person, tr.started_date";
		$db->query($sql,__FILE__,__LINE__);
		$t->set_var("total_day_hours","");

		if ($db->next_record()) {
			$t->set_var("no_records", "");
			$tmp_date = "";
			$tmp_person = "";
			$day_hours = 0;
			$total_day_hours = 0;
			do {
				$date = $db->f("date");
				$rdate = $db->f("rdate");
				$start_time = date("H:i", $db->f("start_time_u"));
				if ($date == $rdate) {
					$end_time = date("H:i", $db->f("end_time_u"));
				}
				else $end_time = date("d M Y H:i", $db->f("end_time_u"));
				if (!$date && $rdate) $date = $rdate;
				$person = $db->f("person");
				$task_title = $db->f("task_title");
				$task_id = $db->f("task_id");
				$time_period = $start_time . " - " . $end_time;
				$spent_hours = $db->f("spent_hours");
				$hours = Hours2HoursMins($spent_hours);
				if ($person_selected) {
					if ($tmp_date!=$date and $tmp_date) {
						$total_day_hours += $day_hours;
						$day_hours = Hours2HoursMins($day_hours);
						$t->set_var("day_hours_html", "<tr><td colspan=3  align=\"right\">Total:</td><td align=\"center\"><font class=\"GridRecordHeader\"><b>$day_hours</b></font></td></tr>");
						$day_hours = 0;
	 				}

	 				else $t->set_var("day_hours_html", "");
					if ($tmp_date != $date) {
						$t->set_var("date_html", "<tr height=10><td colspan=4></td></tr><tr><td colspan=4><font class=\"GridRecordHeader\"><u><b>$date</b></u></font></td></tr>");
					}
					else $t->set_var("date_html", "");

					$t->set_var("for_person", "for $person");
					$t->set_var("person", "");
					$t->set_var("task_title", $task_title);
					$t->set_var("task_id", $task_id);
					$t->set_var("time_period", $time_period);
					$t->set_var("spent_hours", $hours);

					$day_hours += $spent_hours;
	 				$tmp_date = $date;
	 				$tmp_person = $person;
				}
				else {
					if (($tmp_date!=$date and $tmp_date) or ($tmp_person != $person and $tmp_person)) {
						$day_hours = Hours2HoursMins($day_hours);						
						$t->set_var("day_hours_html", "<tr><td colspan=3  align=\"right\">Total:</td><td align=\"center\"><font class=\"GridRecordHeader\"><b>$day_hours</b></font></td></tr>");
						$day_hours = 0;
	 				}
	 				else $t->set_var("day_hours_html", "");

					$t->set_var("for_person", "for all persons");
					if ($tmp_date!=$date) {
						$t->set_var("date_html", "<tr height=10><td colspan=4></td></tr><tr><td colspan=4><font class=\"GridRecordHeader\"><u><b>$date</b></u></font></td></tr>");
						$t->set_var("person", "<b>$person</b>");
					}
					else {
						$t->set_var("date_html","");
						if ($tmp_person!=$person) {
							$t->set_var("person", "<b>$person</b>");
						}
						else $t->set_var("person", "");
					}
					$t->set_var("task_title", $task_title);
					$t->set_var("task_id", $task_id);
					$t->set_var("time_period", $time_period);
					$t->set_var("spent_hours", $hours);

		 			$day_hours += $spent_hours;
	 				$tmp_date = $date;
	 				$tmp_person=$person;
				}
				$t->parse("records", true);
			} while ($db->next_record());
			$tmp_date = "";
			$tmp_person = "";
			if ($total_day_hours) {
				$total_day_hours += $day_hours;
			}
			$day_hours = Hours2HoursMins($day_hours);
			$t->set_var("day_hours_html2", "<tr><td colspan=3  align=\"right\">Total:</td><td align=\"center\"><font class=\"GridRecordHeader\"><b>$day_hours</b></font></td></tr>");			
			if ($total_day_hours) {
				$total_day_hours += 
				$t->set_var("total_day_hours","<br><tr><td colspan=3  align=\"right\">Total of all days:</td><td align=\"center\"><font class=\"GridRecordHeader\"><b>" . Hours2HoursMins($total_day_hours) . "</b></font></td></tr>");
			} else {
				$t->set_var("total_day_hours","");
			}
		}
		else
		{
			$t->set_var("for_person", "");
			$t->set_var("records_header", "");
			$t->set_var("records", "");
			$t->set_var("day_hours_html2", "");
			$t->parse("no_records", false);
		}
		$t->parse("result",false);
	}
	else {
		$t->set_var("for_person", "");
		$t->set_var("result", "");
	}
	$t->set_var("action", 'time_report.php');
	
	$t->pparse("main");
?>