<?php
	include("./includes/common.php");
	CheckSecurity(3);

	if (getsessionparam("privilege_id") == 9) {
		header("Location: index.php");
		exit;
	}

	$task_id	= GetParam("task_id");
	$action		= GetParam("action");
	$is_viart	= GetParam("is_viart");
	$operation	= GetParam("operation");
	$report_user_id	= GetParam("report_user_id");
	
	//-- actions
	if ($action == "close" && $task_id && is_numeric($task_id)) {
		close_task($task_id, GetParam("rp"));
	}

	if ($operation == "save_priorities") {
		save_priorities(false);
	} elseif ($operation == "save_estimates") {
		save_estimates("report_people.php?is_viart=$is_viart&report_user_id=$report_user_id");
	}

	$T = new iTemplate("./templates",array("page"=>"report_people.html"));
	show_report_tasks_list($report_user_id, $is_viart, $_SERVER["REQUEST_URI"]);
  	$T->pparse("page");
?>
