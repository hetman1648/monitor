<?php



	include ("./includes/common.php");
	include ("./includes/date_functions.php");
	if (!defined('INTEGER')) define('INTEGER', 'integer');

	if (getsessionparam("privilege_id") == 9) {
		header("Location: index.php");
		exit;
	}


	$T = new iTemplate("./templates", array("page"=>"view_vacations.html"));
	$user_id = GetSessionParam("UserID");

	// SECOND DATABASE OBJECT
	$db2 = new DB_Sql;
	$db2->Database = DATABASE_NAME;
	$db2->User     = DATABASE_USER;
	$db2->Password = DATABASE_PASSWORD;
	$db2->Host     = DATABASE_HOST;


	// THIRD DATABASE OBJECT
	$db3 = new DB_Sql;
	$db3->Database = DATABASE_NAME;
	$db3->User     = DATABASE_USER;
	$db3->Password = DATABASE_PASSWORD;
	$db3->Host     = DATABASE_HOST;

	CheckSecurity(1);


	// FILTER PARSE
	$search				= "";
	$show_user_id		= GetParam("show_user_id");
	$year_selected		= GetParam("year_selected");
	$filter_start_date  = GetParam("start_date");
	$filter_end_date	= GetParam("end_date");
	$userid				= GetParam("iduser");
	$action				= GetParam("action");
	//echo $start_date." - ".$end_date."<br>";

	if (!$filter_start_date) {$filter_start_date = date("Y-m-d");}


    if ($userid && !$show_user_id) {$show_user_id = $userid;}
     elseif (!$userid && $show_user_id) {$userid = $show_user_id;}

	if ($filter_start_date == 'xxx') $filter_start_date=date('Y-m-00');
	if (strlen($show_user_id)>0 && $show_user_id!=0) $filter_start_date = "";

	if ($year_selected)
	{
	 	$search .= " AND DATE_FORMAT(start_date, '%Y') = '".$year_selected."'";
	}
	if ($filter_start_date) {
		$search .= " AND start_date >= '".$filter_start_date."'";
		//$T->set_var("filter_start_date", $filter_start_date);
	}

	if ($filter_end_date) {
		$search .= " AND start_date <= '".$filter_end_date."'";
		//$T->set_var("filter_end_date", $filter_end_date);
	}

	//if (!$year_selected) {$year_selected = date("Y");}
	//echo $filter_start_date;

	$T->set_var(array(
						"filter_start_date"	=> $filter_start_date,
						"filter_end_date"	=> $filter_end_date,
						"years"				=> GetYearOptions(2004, date("Y"), ((!$year_selected)?date("Y"):$year_selected) ),
						"userid"			=> ((!$userid)?"":$userid)
					));


	//begin National Holidays

	$sql = "SELECT * FROM national_holidays";
	if (strlen($year_selected) > 0)
	{
		$sql .= " WHERE YEAR(holiday_date)=" . ToSQL($year_selected,"NUMBER") . ";";
	}
	else
	{
		$sql .= " WHERE YEAR(holiday_date)=YEAR(NOW());";
	}

	$db->query($sql);

	if ($db->next_record())	{
		$T->parse("holiday_header");
		do {
	  		$T->set_var(array(
	  							"holiday_title" => $db->Record["holiday_title"],
	  							"holiday_date"	=> $db->Record["holiday_date"]
	  						));

	  		$T->parse("national_holidays", true);

		} while ($db->next_record());
	} else {
		$T->set_var("national_holidays", "");
	}

	$user_id = GetSessionParam("UserID");

	if ($user_id == 3 || $user_id == 15){
	  $T->set_var("edit_holidays", "<a href='holidays.php'>Edit holidays</a>");
	} else {
	 	$T->set_var("edit_holidays", "");
	}

	//end National Holidays
	
	//begin English Holidays

	$sql = "SELECT * FROM english_holidays";
	if (strlen($year_selected) > 0)
	{
		$sql .= " WHERE YEAR(holiday_date)=" . ToSQL($year_selected,"NUMBER") . ";";
	}
	else
	{
		$sql .= " WHERE YEAR(holiday_date)=YEAR(NOW());";
	}

	$db->query($sql);

	if ($db->next_record())	{
		$T->parse("english_holiday_header");
		do {
	  		$T->set_var(array(
	  							"holiday_title" => $db->Record["holiday_title"],
	  							"holiday_date"	=> $db->Record["holiday_date"]
	  						));

	  		$T->parse("english_holidays", true);

		} while ($db->next_record());
	} else {
		$T->set_var("english_holidays", "");
	}

	$user_id = GetSessionParam("UserID");

	if ($user_id == 3 || $user_id == 15){
	  $T->set_var("edit_english_holidays", "<a href='holidays.php?type=english'>Edit holidays</a>");
	} else {
	 	$T->set_var("edit_english_holidays", "");
	}

	//end ENglish Holidays	


	// USER STATS PARSE


	$sql = "SELECT user_id, concat(first_name,' ',last_name) as fullname FROM users WHERE is_viart = 1 AND is_deleted IS NULL ";

	$db->query($sql);

	$total_vac = 0;
	$total_pd  = 0;
	$total_ill = 0;

	if ($db->next_record()) {

		do {

			$sql2 = "SELECT total_days, reason_id FROM days_off WHERE is_paid = 0 AND user_id =".$db->Record["user_id"].$search;

			$db2->query($sql2);

			$vacation_i = 0;
			$not_paid_i = 0;
			$illness_i	= 0;
			$total		= 0;

			if ($db2->next_record()) {

				do {					switch ($db2->Record["reason_id"]) {
						case 1: $vacation_i += $db2->Record["total_days"];
								$total 		+= $db2->Record["total_days"];
								$total_vac  += $db2->Record["total_days"];
								break;
						case 2: $not_paid_i += $db2->Record["total_days"];
								$total 		+= $db2->Record["total_days"];
								$total_pd 	+= $db2->Record["total_days"];
								break;
						case 3: $illness_i += $db2->Record["total_days"];
								$total	   += $db2->Record["total_days"];
								$total_ill += $db2->Record["total_days"];
								break;
					}

				}while ($db2->next_record());
			}

			if ($total) {$total = "<B>".$total."</B>";}

			$T->set_var(array(
								"colorrow"	=> "DataRow1",//(($a++)%2 == 1)?"DataRow1":"DataRow3",
								"user_name" => $db->Record["fullname"],
								"vacation"	=> $vacation_i,
								"not_paid"	=> $not_paid_i,
								"illness"	=> $illness_i,
								"total"		=> $total
							));
			$T->parse("not_paid_stats",true);

		}while ($db->next_record());
	}

	$total_abs = $total_vac + $total_ill + $total_pd;

	$colorfont_s = "<font color=\"red\">";
	$colorfont_e = "</font>";

	$T->set_var(array(
						"colorrow"	=> "DataRow2",//(($a++)%2 == 1)?"DataRow1":"DataRow3",
						"user_name" => "Total",
						"vacation"	=> $colorfont_s . $total_vac . $colorfont_e,
						"not_paid"	=> $colorfont_s . $total_pd  . $colorfont_e,
						"illness"	=> $colorfont_s . $total_ill . $colorfont_e,
						"total"		=> $colorfont_s . $total_abs . $colorfont_e
					));
	$T->parse("not_paid_stats",true);



	// MAIN DAYS OFF TABLE PARSE
	if (!$search && !$action) {
		$T->set_var("vacation_td", "");
		$T->set_var("days_off_header", "");

	} else {

		$sql2 = "SELECT * FROM days_off WHERE is_paid = 0".$search;

		if ($show_user_id != 0)	{
			$sql2 .= " AND user_id=".ToSQL($show_user_id, INTEGER);
		}

		$sql2 .= " ORDER BY start_date";

		$db2->query($sql2);

		if ($db2->next_record()) {			do {
				$sql3 = "SELECT user_id, first_name, last_name FROM users";

				$db3->query($sql3);

				while ($db3->next_record()) {
					if ($db3->Record["user_id"] == $db2->Record["user_id"]) {						$user_name = $db3->Record["first_name"]." ".$db3->Record["last_name"];
					}
				}

				$T->set_var("vac_user_name", $user_name);
				$per_title = $db2->Record["period_title"];
				if (!strlen($per_title)) $per_title = "NO TITLE";
				$T->set_var("period_title", "<a href=create_vacation.php?vacation_id=".$db2->Record["period_id"].">".$per_title."</a>");

				$sql3 = "SELECT reason_id, reason_name FROM reasons";

				$db3->query($sql3);

				while ($db3->next_record()) {
					if ($db3->Record["reason_id"] == $db2->Record["reason_id"]) {						$reason_type = $db3->Record["reason_name"];
					}
				}

				$is_approved =  $db2->Record["is_approved"];

				if ($is_approved == NULL) {					$approved = "--"; $T->set_var("color_approved", "black");
				} elseif ($is_approved == 1) {					$approved = "Yes"; $T->set_var("color_approved", "blue");
				} else {					$approved = "No"; $T->set_var("color_approved", "red");
				}


				$is_declined =  $db2->Record["is_declined"];

				if ($is_declined == NULL) {					$declined = "--"; $T->set_var("color_declined", "black");
				} elseif ($is_declined == 1) {					$declined = "Yes"; $T->set_var("color_declined", "red");
				} else {					$declined = "No"; $T->set_var("color_declined", "grey");
				}

				$T->set_var("declined", $declined);
				$T->set_var("approved", $approved);
				$T->set_var("reason_type", $reason_type);
				$T->set_var("start_date", norm_sql_date($db2->Record["start_date"]));
				$T->set_var("end_date", norm_sql_date($db2->Record["end_date"]));
				$T->set_var("total_days", $db2->Record["total_days"]);
				$T->parse("vacation_td", true);

			} while ($db2->next_record());
		} else {
		  $T->set_var("reason_type", "");
		  $T->set_var("start_date", "");
		  $T->set_var("end_date", "");
		  $T->set_var("total_days", "");
		  $T->set_var("period_title", "");
		  $T->set_var("approved", "");
		  $T->set_var("declined", "");
		  $T->set_var("vac_user_name", "No vacations on the selected period");
		}
	}


	// MAIN DAYS OFF TABLE PARSE
	if (!$search && !$action) {
		$T->set_var("paid_days_header", "");
		$T->set_var("vacation_td_paid", "");

	} else {

		$sql2 = "SELECT * FROM days_off WHERE is_paid = 1".$search;
		if ($show_user_id)
		{
		  $sql2 .= " AND user_id=".ToSQL($show_user_id, INTEGER);
		}
		$sql2 .= " ORDER BY start_date";
		$db2->query($sql2);
		//echo $sql2."<br>".$db2->nf()."<br>";

		if ($db2->next_record()) {
			do {
		 // echo "111";
		 // exit;
				$sql3 = "SELECT user_id, first_name, last_name FROM users";
				$db3->query($sql3);
				while ($db3->next_record()) {
				  if ($db3->Record["user_id"] == $db2->Record["user_id"]) {				  	$user_name = $db3->Record["first_name"]." ".$db3->Record["last_name"];
				  }
				}

				$T->set_var("username_pd", $user_name);
				$T->set_var("period_title", "<a href=create_vacation.php?vacation_id=".$db2->Record["period_id"].">".$db2->Record["period_title"]."</a>");

				$sql3 = "SELECT reason_id, reason_name FROM reasons";

				$db3->query($sql3);

				while ($db3->next_record()) {
					if ($db3->Record["reason_id"] == $db2->Record["reason_id"]) {						$reason_type = $db3->Record["reason_name"];
					}
				}

				$is_declined =  $db2->Record["is_declined"];

				if ($is_declined == NULL) {					$declined = "--"; $T->set_var("color_declined", "black");
				} elseif ($is_declined == 1) {					$declined = "Yes"; $T->set_var("color_declined", "red");
				} else {					$declined = "No"; $T->set_var("color_declined", "grey");
				}

				$is_approved =  $db2->Record["is_approved"];

				if ($is_approved == NULL) {					$approved = "--"; $T->set_var("color_approved", "black");
				} elseif ($is_approved == 1) {					$approved = "Yes"; $T->set_var("color_approved", "blue");
				} else {					$approved = "No"; $T->set_var("color_approved", "red");
				}


				$T->set_var("declined", $declined);
				$T->set_var("approved", $approved);
				$T->set_var("reason_type", $reason_type);
				$T->set_var("start_date", norm_sql_date($db2->Record["start_date"]));
				$T->set_var("end_date", norm_sql_date($db2->Record["end_date"]));
				$T->set_var("total_days", $db2->Record["total_days"]);
				$T->parse("vacation_td_paid", true);

			} while ($db2->next_record());
		} else {

			  $T->set_var("reason_type", "");
			  $T->set_var("start_date", "");
			  $T->set_var("end_date", "");
			  $T->set_var("total_days", "");
			  $T->set_var("period_title", "");
			  $T->set_var("approved", "");
			  $T->set_var("declined", "");
			  $T->set_var("username_pd", "No paid days on the selected period");
		}
	}


	//begin holidays summary
	//$today = getdate();
	$today_year = date("Y");;//$today["year"];
	$nowday = date('Y-m-d');
	if ($user_id == 3){
		$T->set_var("add_holiday", "<a href='add_to_holiday.php'>Add Holiday</a>");
	} else {
		$T->set_var("add_holiday", "");
	}

		$sql = "SELECT start_date, user_id, CONCAT(first_name, ' ', last_name) AS user_name FROM users WHERE is_viart=1 AND is_deleted IS NULL";
		$db->query($sql);
		$T->parse("header_holiday_summary");
					while ($db->next_record())
					{
					  	$T->set_var("hol_user_name", $db->f("user_name"));
					  	$url = "";
					  	if ($year_selected) {$url .= "&year_selected=$year_selected";}
					  	 else {$url .= "&year_selected=$today_year";}
					  	if ($filter_start_date) {$url .= "&start_date=$filter_start_date";}
					  	if ($filter_end_date) {$url .= "&end_date=$filter_end_date";}

					  	if (strlen($url) > 0) {					  		$T->set_var("show_user_id", $db->f("user_id").$url);
					  	}
					  	else {$T->set_var("show_user_id", $db->f("user_id"));}
                        unset($url);

					  	$T->set_var("work_start", $db->f("start_date"));
							$sql2 = "SELECT SUM(total_days) AS used_holidays FROM days_off WHERE reason_id = 1 AND is_paid=0  AND user_id=".ToSQL($db->f("user_id"), INTEGER);
							$db2->query($sql2);
							if ($db2->next_record()) {
							  $used_holidays = $db2->f("used_holidays");
								$T->set_var("used_holidays", $used_holidays);//Used days
							}

							$sql2 = "SELECT SUM(total_days) AS used_holidays FROM days_off WHERE reason_id = 1 AND is_paid=0 AND user_id=".ToSQL($db->f("user_id"), INTEGER);
							$sql2 .= " AND DATE_FORMAT(start_date, '%Y')='$today_year'";
							$db2->query($sql2);
							if ($db2->next_record()) {
								$T->set_var("used_holidays_year", $db2->f("used_holidays"));//Used  days this_year
							}

							$sql2 = "SELECT SUM(days_number) AS total_holidays FROM holidays WHERE user_id=".ToSQL($db->f("user_id"), INTEGER);
							$db2->query($sql2);
							if ($db2->next_record())
							{
							  $total_holidays = floor($db2->f("total_holidays"));
							  $T->set_var("total_holidays", $total_holidays);

							}

							$sql2 = "SELECT SUM(days_number) AS total_holidays FROM holidays WHERE user_id=".ToSQL($db->f("user_id"), INTEGER);
							$sql2 .= " AND DATE_FORMAT(date_added, '%Y')='$today_year'";
							$db2->query($sql2);
							if ($db2->next_record())
							{
								$T->set_var("total_holidays_year", floor($db2->f("total_holidays")));
							}

							$T->set_var("this_year",$today_year);
							$T->set_var("avail_holidays", $total_holidays - $used_holidays);
							$T->parse("holiday_summary", true);


					}

	//end holidays summary

	// create table delay_notifications if it not exists

	$sql2="CREATE TABLE IF NOT EXISTS delay_notifications(
				note_id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
					PRIMARY KEY(note_id),
				user_id INT(11) UNSIGNED NOT NULL,
				date_added DATE NOT NULL,
				note_date DATE NOT NULL,
				notes TEXT
			)";

	$db->query($sql2);


	// MAIN DELAY NOTES TABLE PARSE

	if (!$search && !$action) {		$T->set_var("delay_notes", "");
		$T->set_var("delay_not_header", "");
	} else {

		$sql2 = "SELECT n.created_user_id,
						CONCAT(u.first_name, ' ' , u.last_name) as user_name,
						n.notes as delay_descr,
						n.note_id as note_id,
						note_date as date,
						date_added as add_date
				FROM users u, delay_notifications n
				WHERE u.user_id=n.user_id ".str_replace('start_date','note_date',$search);

		if ($show_user_id) { $sql2 .= " AND u.user_id=".$show_user_id; }

		$db2->query($sql2);

		if ($db2->next_record()) {			do {
				$sql = 'SELECT CONCAT(first_name, \' \', last_name) as user_name FROM users WHERE user_id = '.ToSQL($db2->Record['created_user_id'], 'integer');
				$db3->query($sql);
				$db3->next_record();

				$T->set_var("username_dn", $db2->Record["user_name"]);
				$T->set_var("created_user_name", $db3->Record["user_name"]);
				$T->set_var("delay_descr", '<a href=create_delay_note.php?note_id='.$db2->Record["note_id"].'>'.$db2->Record["delay_descr"].'</a>');
				$T->set_var("date", $db2->Record["date"]);
				$T->set_var("add_date", $db2->Record["add_date"]);
			 	$T->parse("delay_notes", true);
			} while ($db2->next_record());
		} else {

		  	$T->set_var("username_dn", 'No Notifications on the selected period');
			$T->set_var("delay_descr", '');
			$T->set_var("date", '');
			$T->set_var("add_date", '');
			$T->set_var("created_user_name", "");
		 	$T->parse("delay_notes", true);
		}

	}


	$T->pparse("page", false);
?>