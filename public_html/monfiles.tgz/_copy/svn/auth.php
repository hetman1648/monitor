<?
/*
include auth file for common 
*/

$user_id = GetSessionParam("UserID");
if($user_id == "") {
	header("Location:../login.php");
	exit;
}

$svn_login    = "";
$svn_password = "";
$sql  = "SELECT svn_login,svn_password FROM users WHERE user_id=$user_id";
$db->query($sql);
if ($db->next_record()) {
	$svn_login    = $db->f("svn_login");
	$svn_password = $db->f("svn_password");
}

if (!$svn_login || !$svn_password) die("To access this module please ask Vlad to issue SVN login/password for you");

$svn_path    = "https://web1.sayu.co.uk/svn/";

function get_page($url,$user_agent='Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)') 
{ 
    $options = array( 
        CURLOPT_RETURNTRANSFER => true,     // return web page 
        CURLOPT_HEADER         => false,    // return headers 
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects 
        CURLOPT_ENCODING       => "",       // handle all encodings 
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect 
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect 
        CURLOPT_TIMEOUT        => 120,      // timeout on response 
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects 
        CURLOPT_USERAGENT	   => $user_agent,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_URL            => $url
    ); 


	$ch = curl_init(); 
	curl_setopt_array( $ch, $options ); 
//	curl_setopt ($ch, CURLOPT_URL, $url); 
//	curl_setopt ($ch, CURLOPT_USERAGENT, $user_agent); 
//	curl_setopt ($ch, CURLOPT_HEADER, 0); 
//	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
//	curl_setopt ($ch, CURLOPT_REFERER, 'http://www.pcpropertymanager.com/wsnlinks/');
	$result = curl_exec ($ch); 
	$info = curl_getinfo($ch);
	/*	echo "<b>curl Error:</b>".curl_error($ch)."<hr>";
    	if (is_array($info)) {
    		print_r($info);
    	} else {
    		echo $info;
    	}
    	*/
	curl_close ($ch); 

	$msg = "URL:$url\n";
	$msg.= "Curl Error: curl_error($ch)\n";
	if (is_array($info)) {
		$msg.= "info:".join("-",$info);
	} else {
		$msg.= "info:".$info;
	}

	//mail("artem.birzul@gmail.com","test mobile check", $msg);
	
	return $result; 
} 

?>