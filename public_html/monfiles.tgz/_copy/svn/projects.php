<?php

$root_inc_path = "../";
//include ("../includes/common.php");
//include ("./auth.php");



?>

<!DOCTYPE html>
<html>
  <head>
    <title>Sayu Web Clients Projects Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <style>
    	#divRepositoryPath  {
    		font-size:10px;
    	}
      .taskBusy {
        background-color: #dff0d8;
      }
      .projectBusy {
        background-color: blue;
      }
    </style>
  </head>
  <body>

 <div class="container-fluid">
 
      <form class="form-signin">
      	<a href="../index.php" style="margin-top:5px;"><i class="icon-home"></i> Back to Monitor</a>
        <h2 class="form-signin-heading">Projects List</h2>
        <!-- Find a Repository: 
        <input type="text" class="span3" id="lstRepositories" autocomplete="off" value="<?php echo $monitor_svn_repository; ?>" style="margin: 0 auto; width:300px;" data-provide="typeahead" data-items="4" >
      -->
        
        <!--<blockquote class="pull-right">
      <p>It is extraordinary that whole populations have no projects for the future, none at all. It certainly is extraordinary, but it is certainly true.</p>
          <small><cite title="Source Title">Gertrude Stein</cite></small>
 </blockquote>-->

 <div class="btn-group pull-right" >
  <button class="btn">Show Calendar (2 weeks)</button>
  <button class="btn dropdown-toggle" data-toggle="dropdown">
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu pull-right">
    <!-- dropdown menu links -->
      <li><a href="#">Week</a></li>
      <li><a href="#">2 weeks</a></li>
      <li><a href="#">Month</a></li>
      <li><a href="#">2 months</a></li>
  </ul>
</div>

<div id="divProjects"></div>

        <div id="divRepositoryPath"></div>
        <div id="divFilesList"></div>
      </form>

      

<!-- Button to trigger modal -->
<!--<a href="#myModal" role="button" class="btn" data-toggle="modal">Launch demo modal</a>-->
 
<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
    <h3 id="myModalLabel">History</h3>
  </div>
  <div class="modal-body">
    <p id="infoBox"></p>
  </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
  </div>
</div>
      
    </div> <!-- /container -->

    <script src="https://code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
    var defaultRepository = "<?php echo $monitor_svn_repository; ?>";
    $(document).ready(function() {  
    	
		$('#myModal').on('show', function () {
			repository = $("#lstRepositories").val();
        	$.post("history.php", {repository:repository}, function(xml) {
        		$("#infoBox").html(xml);
        	});    		
		})    	

    	get_projects();
    	
	});

	function get_projects() {
		$.post("get_projects.php", {repository:1}, function(xml) {
			$("#divProjects").html(xml);
    });		
	}
    
    </script>
  </body>
</html>