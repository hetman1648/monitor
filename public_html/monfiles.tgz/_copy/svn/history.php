<?php
/*
	run this file from AJAX call to get a history of all update operation in specified repository
	@param: repository
*/

$root_inc_path = "../";
include ("../includes/common.php");
include ("./auth.php");

$repository = GetParam("repository");
if (!strlen($repository)) die ("Please specify SVN repository");


	$users = array();
   	$sql = "SELECT user_id,first_name,last_name FROM users ";
   	$db->query($sql);
   	while ($db->next_record()) {
   		$users[$db->f("user_id")] = $db->f("first_name"). " ".$db->f("last_name");
   	}

	$sql = "SELECT date_added,user_id FROM svn_updates WHERE repository='".$repository."' ORDER BY date_added DESC";
	//echo $sql;
	$db->query($sql); $c = 0; $valid_rows = array();
	
?>
        <table class="table table-striped">
        	<tr>
        		<th>User</th>
        		<th>Date</th>
        	</tr>
        	<?php while ($db->next_record()) { ?>
        	<tr>
        		<td><? echo $users[$db->f("user_id")]; ?></td>
        		<td><? echo $db->f("date_added"); ?></td>
        	</tr>
        	<?php $c++; } ?>
        </table>

<?php        

	if (!$c) die ("<div class='alert alert-info'>No history for <b>".$repository."</b> </div>");

?>
        