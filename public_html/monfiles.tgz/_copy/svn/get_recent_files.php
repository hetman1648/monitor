<?php
/*
	run this file from AJAX call to get list of all recently updated files in specified repository
	@param: repository
*/

$root_inc_path = "../";
include ("../includes/common.php");
include ("./auth.php");

$repository = GetParam("repository");
if (!strlen($repository)) die ("Please specify SVN repository");
$command = "index.php?action=showupdates&username=".$svn_login."&password=".$svn_password."&repository=".$repository;
$res = get_page($svn_path. $command); 

$statuses = array("*" => "CHANGED",
                  "A" => "To Add",
                  "D" => "To Delete",
                  "M" => "MODIFIED",
                  "D" => "To Delete",
                  "?" => "NOT IN SVN",
                  "!" => "MISSING",
                  "L" => "LOCKED"
                  );


if (strpos($res,'Server response is: +OK') !== false) {
	$lines = explode("Server response is: +OK Updates:", $res);

	$sql = "SELECT date_added,user_id FROM svn_updates WHERE repository='".$repository."' ORDER BY date_added DESC";
	//echo $sql;
	$db->query($sql);
	$last_update = ""; $last_user_id = 0;
	if ($db->next_record()) {
		$last_update  = $db->f("date_added");
		$last_user_id = $db->f("user_id");
	}
	if (strlen($last_update)) {
		$last_update = "Last update:".$last_update;
		if ($last_user_id) {
			$sql = "SELECT first_name,last_name FROM users WHERE user_id=".$last_user_id;
			$db->query($sql);
			if ($db->next_record()) {
				$last_update .= " by ".$db->f("first_name"). " ".$db->f("last_name");
			}
		}
		if ($last_update) {
			$last_update.= " <a href='#myModal' role='button' id='bntHistory' class='btn btn-mini btn-info' data-toggle='modal'>History</a>";
		}
	}

	
	if (sizeof($lines) >1) {
	    $rows = explode("\n",$lines[1]);
	    if (GetParam("artem") == "test") {
	    	echo $lines[1];
	    	exit;
	    }
	    //getting rid of emply lines and status line
	    $valid_rows = array();
	    foreach ($rows as $row) {
	    	if (!(strpos($row,'Status against revision') !== false)) {
		    	if (strlen(trim($row))) {
		    		
		    		//preg_match_all("||U", $row, $matches);
		    		$row = preg_replace("/\s+/"," ",$row);
		    		$fields = explode(" ",$row);
		    		$status = $fields[1];
		    		if (isset($statuses[$status])) $status = $statuses[$status];
		    		if (!$fields[3]) {
		    			$fields[3] = $fields[2];
		    			$fields[2] = "-";
		    			$status    = "NEW";
		    		}
		    		$valid_rows[] = array(  "status"    => $status,
								    		"version"   => $fields[2],
		    								"file_name" => basename($fields[3]),
		    								"file_path" => str_replace(basename($fields[3]),"",$fields[3])
		    		);
		    		
		    		//print_r($fields);
		    	}
	    	}
	    }
	    setcookie("monitor_svn_repository" ,$repository, time()+60*60*24*180);
	    if (!sizeof($valid_rows)) die ("<div class='alert alert-info'>No files to update for <b>".$repository."</b> ".$last_update."</div>");
    } else die ("OK: no updates");
}
else die("ERROR:".$res);

?>
	<div class='alert alert-info'>
		<?php echo sizeof($valid_rows); ?> update<?php if (sizeof($valid_rows)>1) echo "s" ?> found. <? echo $last_update; ?>
	</div>
        <table class="table table-striped">
        	<tr>
        		<th>File Path</th>
        		<th>File Name</th>
        		<th>Status</th>
        		<th>Revision</th>
        	</tr>
        	<?php foreach ($valid_rows as $fields) { ?>
        	<tr>
        		<td><? echo $fields["file_path"]; ?></td>
        		<td><? echo $fields["file_name"]; ?></td>
        		<td><? echo $fields["status"]; ?></td>
        		<td><? echo $fields["version"]; ?></td>
        	</tr>
        	<?php } ?>
        	<input type="hidden" id="hdnFilesNumber" value="<?php echo sizeof($valid_rows); ?>">
        </table>