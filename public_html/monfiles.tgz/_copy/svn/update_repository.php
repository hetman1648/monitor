<?php
/*
	run this file from AJAX call to update the site with a working copy of repository
	@param: repository
*/

$root_inc_path = "../";
include ("../includes/common.php");
include ("./auth.php");

$repository = GetParam("repository");
if (!strlen($repository)) die ("Please specify SVN repository");
$command = "index.php?action=checkout&username=".$svn_login."&password=".$svn_password."&repository=".$repository;
$res = get_page($svn_path. $command); 

$sql = "INSERT INTO svn_updates (user_id,date_added,repository) VALUES ($user_id,NOW(),'".$repository."')";
$db->query($sql);

echo $res;