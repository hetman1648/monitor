<?php
	include("./includes/date_functions.php");
	include("./includes/common.php");
	CheckSecurity(1);
	$T = new iTemplate($sAppPath);
	$T->set_file("main","create_client.html");
	$sort = GetParam("sort");
	
	$new_sayu_user = 0;

	$action_value	= GetParam("action_value");
	$action			= GetParam("action");
	$client_name	= trim(GetParam("client_name"));
	$sayu_user_id	= GetParam("sayu_user_id");
	$client_email	= GetParam("client_email");
	$is_viart		= GetParam("is_viart")=="on"?1:0;
	$is_viart_hosted= GetParam("is_viart_hosted")=="on"?1:0;
	$notes			= GetParam("notes");
	$client_id		= GetParam("client_id");
	$delete			= GetParam("delete");
	$date_added		= GetParam("date_added");
	$company_name	= GetParam("company_name");
	$google_id		= GetParam("google_id");
	$mcc_account	= GetParam("mcc_account");
	$is_sayu_active	= GetParam("is_sayu_active");
	$client_type	= GetParam("client_type");
	$new_sayu_user  = GetParam("new_sayu_user");

	$error = "";

	if ($action == "Cancel") {
			header("Location: view_clients.php");
	}

	// SECOND DATABASE OBJECT

	$db2 = new DB_Sql;
	$db2->Database = DATABASE_NAME;
	$db2->User     = DATABASE_USER;
	$db2->Password = DATABASE_PASSWORD;
	$db2->Host     = DATABASE_HOST;

	if ($action_value == 'Update Client'){		if (!$client_name) { $error .= "<b>Client name</b> is required<br>";}
		if (!$error) {			$sql = "UPDATE clients
					SET	sayu_user_id	= ".ToSQL($sayu_user_id,"integer",false,false).",
						client_name		= ".ToSQL($client_name,"string").",
						client_company	= ".ToSQL($company_name,"string").",
						client_email	= ".ToSQL($client_email,"string").",
						account_mcc		= ".ToSQL($mcc_account,"string").",
						google_id		= ".ToSQL($google_id,"string").",
						is_viart		= ".ToSQL($is_viart,"integer",false,false).",
						is_viart_hosted = ".ToSQL($is_viart_hosted,"integer",false,false).",
						notes			= ".ToSQL($notes,"string");
			//if ($client_type == 2){ // if clients is Sayu
			//	$sql .= " ,is_active = " . ToSQL($is_sayu_active,"integer",false,false);
			//}
			$sql .=	"	WHERE client_id = ".ToSQL($client_id,"integer",false,false);
			$db->query($sql,__FILE__,__LINE__);
			header("Location: view_clients.php");
		}
	}
	elseif ($action_value == 'Create Client'){		if (!$client_name) { $error .= "<b>Client name</b> is required<br>";}
		if (!$error) {
			$sql = "INSERT INTO clients SET	";
			if ($new_sayu_user == 1)
				$sql .=	" sayu_user_id	= -1,"; 
				else $sql .=	"	sayu_user_id	= ".ToSQL($sayu_user_id,"integer").",";
			$sql .=	"   client_name		= ".ToSQL($client_name,"string").",
						client_company	= ".ToSQL($company_name,"string").",
						client_email	= ".ToSQL($client_email,"string").",
						account_mcc		= ".ToSQL($mcc_account,"string").",
						google_id		= ".ToSQL($google_id,"string").",
						is_viart		= ".ToSQL($is_viart,"integer").",
						is_viart_hosted = ".ToSQL($is_viart_hosted,"integer").",
						notes			= ".ToSQL($notes,"string").",
						date_added = NOW()";
			$db->query($sql,__FILE__,__LINE__);
			$sql="SELECT LAST_INSERT_ID() as last_id";
			$db->query($sql,__FILE__,__LINE__);
			$db->next_record();
			header("Location: create_client.php?client_id=".$db->Record["last_id"]);
		}
	}

	if ($delete){		$sql = 'DELETE FROM clients_sites WHERE client_id = '.ToSQL($client_id,"integer");
		$db->query($sql,__FILE__,__LINE__);
		$sql = 'DELETE FROM clients WHERE client_id = '.ToSQL($client_id,"integer");
		$db->query($sql,__FILE__,__LINE__);
		header("Location: view_clients.php");

	}


    if ($error) {    	$T->set_var("error_message",$error);
    	$T->parse("error", false);    }
    else { $T->set_var("error","");}

	if ($client_id) {
	    $T->set_var('add_site', 'Add new site for this user');
		$sql="SELECT	notes,
						client_name,
						sayu_user_id,
						client_email,
						client_company,
						account_mcc,
						google_id,
						IF(is_viart=1, 'checked', '') as is_viart,
						IF(is_viart_hosted=1, 'checked', '') as is_viart_hosted,
						IF(is_active=1, 'checked', '') as is_sayu_active,
						client_type,
						client_id,
						DATE(date_added) as date_added
				FROM clients
				WHERE client_id=".ToSQL($client_id,"integer");
		$db->query($sql,__FILE__,__LINE__);

		if ($db->next_record()){
			$T->set_var(array(
					'sayu_user_id'	=> $db->Record['sayu_user_id'],
					'client_name'	=> $db->Record['client_name'],
					'client_email'	=> $db->Record['client_email'],
					'company_name'	=> $db->Record['client_company'],
					'mcc_account'	=> $db->Record['account_mcc'],
					'google_id'		=> $db->Record['google_id'],
					'is_viart'		=> $db->Record['is_viart'],
					'is_viart_hosted'=> $db->Record['is_viart_hosted'],
					'date_added'	=> $db->Record['date_added'],
					'client_id'		=> $db->Record['client_id'],
					'notes'			=> $db->Record['notes'],
					'client_type'	=> $db->Record['client_type'],
					'delete_button'	=> '<input onclick="return confirm(\'Are you sure?\');" type=submit name="delete" value="Delete Client">',
					'action_value'	=> 'Update Client'
			));
			if ($db->Record['client_type'] == 2) {				$T->set_var("is_sayu_active",$db->Record['is_sayu_active']);			}
			else { $T->set_var("sayu_clients","");}
		}

		$sql2="SELECT	site_id,
						web_address,
						admin_web_address,
						admin_web_site_login,
						admin_web_site_password,
						CONCAT(ftp_address, '<br>', ftp_login, '<br>', ftp_password) as ftp,
						CONCAT(admin_web_address, '<br>', admin_web_site_login, '<br>',  admin_web_site_password) as admin,
						DATE(date_added) as date_added,
						DATE(date_changed) as date_changed,
						notes
				FROM clients_sites
				WHERE client_id = ".ToSQL($client_id,"integer");
	    $db->query($sql2,__FILE__,__LINE__);
	    if($db->next_record()) {
	    	do{
	    		$site_id           = $db->f('site_id');
	    		$web_address       = str_replace("http://","",$db->Record['web_address']);
	    		$admin_web_address = str_replace("http://","",$db->Record['admin_web_address']);
	    		$admin_web_address = str_replace($web_address, "", $admin_web_address)."/";
	    		$admin_web_address = str_replace("//", "/", $admin_web_address);
	    		$svn_domain        = str_replace("http://www.","",$db->Record['web_address']);
	    		$svn_domain        = str_replace("http://web1.sayu.co.uk/~","",$svn_domain);
	    		$svn_domain        = rtrim($svn_domain,"/");

		    	$T->set_var(array(
		    			'web_address'	=> $web_address,
		    			'ftp'			=> $db->Record['ftp'],
		    			'admin_url'		=> $admin_web_address,
		    			'admin'			=> $db->Record['admin'],
		    			'admin_login'	=> $db->Record['admin_web_site_login'],
		    			'admin_password'=> $db->Record['admin_web_site_password'],
		    			'date_added_web'=> $db->Record['date_added'],
		    			'date_changed'	=> $db->Record['date_changed'],
		    			'notes'			=> $db->Record['notes'],
		    			'site_id'		=> $db->Record['site_id'],
		    			'domain_name'   => $svn_domain,
		    			'no_sites'		=> '',
		    			'tag'           => ''
		    	));		    	
		    	$sql  = " SELECT t.title FROM clients_sites_tags st";
				$sql .= " INNER JOIN clients_tags t ON t.id=st.tag_id";
				$sql .= " WHERE st.site_id=" . ToSQL($site_id, "integer");
				$db2->query($sql, __FILE__,__LINE__);
				if ($db2->next_record()){					
					do {
						$T->set_var("tag_title", $db2->f("title"));
						$T->parse("tag");
					} while($db2->next_record());					
				}
	 			$T->parse('sites', true);
	    	} while($db->next_record());
	    } else{	   		
	    	$T->set_var('sites', '');
	   		$T->parse('no_sites', true);	    
	    }
	} else {		
		$T->set_var(array(
				'is_viart_hosted'=> $is_viart_hosted?'checked':'',
				'add_site'		=> '',
				'no_sites'		=> '',
				'company_name'	=> $company_name,
				'mcc_account'	=> $mcc_account,
				'google_id'		=> $google_id,				'sayu_user_id'	=> $sayu_user_id,
				'client_name'	=> $client_name,
				'client_email'	=> $client_email,
				'is_viart'		=> $is_viart?'checked':'',
				'sites'			=> '',
				'date_added'	=> $date_added,
				'client_id'		=> '',
				'notes'			=> $notes,
				'delete_button'	=> '',
				'action_value'	=> 'Create Client',
				'sayu_clients'	=> '',
				'client_type'	=> 1,
				'new_sayu_user'	=> $new_sayu_user
		));
	}

	$T->pparse("main", false);
?>

