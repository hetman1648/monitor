<?php

	define("DATABASE_NAME","monitor");
	define("DATABASE_USER","monitor");
	define("DATABASE_PASSWORD","t3stt1m3");
	define("DATABASE_HOST","localhost");

	define("VIART_COM_DATABASE_NAME","c2s");
	define("VIART_COM_DATABASE_USER","c2s");
	define("VIART_COM_DATABASE_PASSWORD","NNmwb-2G");
	define("VIART_COM_DATABASE_HOST","62.149.0.96:3309");
	
	define("SAYU_DATABASE_NAME","sayu");
	define("SAYU_DATABASE_USER","sayu");
	define("SAYU_DATABASE_PASSWORD","cnfn=06");
	define("SAYU_DATABASE_HOST","80.87.133.164:3310");
	
?>