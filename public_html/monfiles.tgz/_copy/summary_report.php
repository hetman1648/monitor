<?php

	include("./includes/date_functions.php");
	include("./includes/common.php");

	CheckSecurity(1);

	$db2 = new DB_Sql;
	$db2->Database = DATABASE_NAME;
	$db2->User     = DATABASE_USER;
	$db2->Password = DATABASE_PASSWORD;
	$db2->Host     = DATABASE_HOST;

	$db3 = new DB_Sql;
	$db3->Database = DATABASE_NAME;
	$db3->User     = DATABASE_USER;
	$db3->Password = DATABASE_PASSWORD;
	$db3->Host     = DATABASE_HOST;

	$person_selected	= GetParam("person_selected");
	$year_selected		= GetParam("year_selected");
	$month_selected		= GetParam("month_selected");
    $team				= GetParam("team");
	$multiplier			= GetParam("multiplier");
	$total_viart		= GetParam("total_viart");

	$submit = GetParam("submit");

	$holiday_dates = array_fill(1,31,0);

	if (floatval($multiplier)==0 || floatval($multiplier)<=0 ) {
		$multiplier = 1;
	}
	if (floatval($total_viart)==0 || floatval($total_viart)<=0 ) {
		$total_viart = 1;
	}
	
	if (!$year_selected) $year_selected = date("Y");
	if (!$month_selected) $month_selected = date("m");

	//team select block
	$as =""; $vs =""; $ys ="";
	switch (strtolower($team))
	{
	  case "all":	$sqlteam=""; $as="selected"; break;
	  case "viart":	$sqlteam=" AND u.is_viart=1 "; $vs="selected"; break;
	  case "yoonoo":$sqlteam=" AND u.is_viart=0 "; $ys="selected"; break;
	  default:	$sqlteam=" AND u.is_viart=1 "; $vs="selected"; $team="viart";
	}

	$t = new iTemplate($sAppPath);
	$t->set_file("main","summary_report.html");

	$t->set_var("multiplier", $multiplier);
	$t->set_var("total_viart",$total_viart);
	$t->set_var("months", GetMonthOptions($month_selected));
	$t->set_var("years", GetYearOptions(2004, date("Y"), $year_selected));
	$t->set_var("aselected",$as); $t->set_var("vselected",$vs); $t->set_var("yselected",$ys); $t->set_var("team_selected",$team);

			//begin planned days
			$sql2 = " SELECT CONCAT(u.first_name, ' ', u.last_name) AS user_name, ";
			$sql2 .= " COUNT(DISTINCT DATE_FORMAT(tr.started_date, '%Y %m %d')) AS work_days ";
			$sql2 .= " FROM time_report tr, users u";
			$sql2 .= " WHERE WEEKDAY(tr.started_date)<=4 AND tr.user_id=u.user_id ";
			if ($year_selected) $sql2 .= " AND DATE_FORMAT(tr.started_date, '%Y')='$year_selected' ";
			if ($month_selected) $sql2 .= " AND DATE_FORMAT(tr.started_date, '%m')='$month_selected' ";
			$sql2 .= " GROUP BY user_name ";
			$db2->query($sql2,__FILE__,__LINE__);
			//-- Number of work days that person worked during month
			$work_days = array();
			while ($db2->next_record()) {
				$work_days[$db2->f("user_name")] = $db2->f("work_days");
			}
			$working_days_planned = 0;

			$sql2 = " SELECT CONCAT(u.first_name, ' ', u.last_name) AS user_name, u.user_id, ";
			$sql2 .= " COUNT(DISTINCT DATE_FORMAT(tr.started_date, '%Y %m %d')) AS working_days ";
			$sql2 .= " FROM time_report tr, users u ";
			$sql2 .= " WHERE tr.user_id=u.user_id ";
			if ($year_selected) $sql2 .= " AND DATE_FORMAT(tr.started_date, '%Y')='$year_selected' ";
			if ($month_selected) $sql2 .= " AND DATE_FORMAT(tr.started_date, '%m')='$month_selected' ";
			$sql2 .= " GROUP BY user_name ";
			$sql2 .= " ORDER BY user_name ";
			$db2->query($sql2,__FILE__,__LINE__);
			
			if ($db2->next_record()) {
				do {
					$user_name = $db2->f("user_name");
					if (array_key_exists($user_name,$work_days)) {
						if ($working_days_planned <=  $work_days[$user_name]) {
							$working_days_planned = $work_days[$user_name];
						}
					}
				} while ($db2->next_record());
			}

			$sql2 = "SELECT * FROM national_holidays";
			if ($year_selected) $sql2 .= " WHERE DATE_FORMAT(holiday_date, '%Y')='$year_selected' ";
			if ($month_selected) $sql2 .= " AND DATE_FORMAT(holiday_date, '%m')='$month_selected' ";
			$db2->query($sql2,__FILE__,__LINE__);
			if ($db2->next_record())
			{
			  do {
			  		$hol_date = $db2->Record["holiday_date"];
					$hol_date_arr = explode("-",$hol_date);
					$week_day = date("w", mktime(0,0,0,$hol_date_arr[1], $hol_date_arr[2], $hol_date_arr[0]));
					  if (($week_day!=0) && ($week_day!=6)) {
						$working_days_planned = $working_days_planned - 1;
					}
				}
				while ($db2->next_record());
			}
			$t->set_var("working_days_planned", $working_days_planned);

	//end planned days
	if ($submit) {
		if ($year_selected && $month_selected) {
		
			$sqldata = "";
			$user_ids = array();
			$viart_users_time = array();
			$sayu_users_time = array();
			
			if ($year_selected) { $sqldata .= " AND DATE_FORMAT(tr.started_date, '%Y')='$year_selected' ";}
			if ($month_selected) { $sqldata .= " AND DATE_FORMAT(tr.started_date, '%m')='$month_selected' ";}

			$sql  = " SELECT u.user_id FROM users u WHERE 1 " . $sqlteam;
			$sql .= " ORDER BY u.user_id";
			$user_ids = db_once_query($sql,true);
			foreach($user_ids as $k => $v_id) {
				$viart_users_time[$v_id] = 0;
				$sayu_users_time[$v_id] = 0;
			}
			$sqlviart = " WHERE pp.project_title like 'viart' ";
			$sqlsayu = " WHERE not pp.project_title like 'viart' ";
			
			$sqlM  = " SELECT	SUM(tr.spent_hours) AS count_hours ";
			$sqlM .= " FROM	((((projects pp ";
			$sqlM .= " INNER JOIN projects p ON (IF (p.parent_project_id, p.parent_project_id, p.project_id)=pp.project_id)) ";
			$sqlM .= " INNER JOIN tasks t ON (t.project_id = p.project_id)) ";
			$sqlM .= " INNER JOIN time_report tr ON (t.task_id = tr.task_id " . $sqldata . ")) ";
			$sqlM .= " INNER JOIN users u ON (tr.user_id=u.user_id AND u.is_viart=1)) ";
			$viart_total_time = db_once_query($sqlM . $sqlviart,true);
			$sayu_total_time = db_once_query($sqlM . $sqlsayu,true);
			
			$sqlM  = " SELECT	tr.user_id AS user_id, SUM(tr.spent_hours) AS count_hours ";
			$sqlM .= " FROM	projects pp ";
			$sqlM .= " INNER JOIN projects p ON (IF (p.parent_project_id, p.parent_project_id, p.project_id)=pp.project_id) ";
			$sqlM .= " INNER JOIN tasks t ON (t.project_id = p.project_id) ";
			$sqlM .= " INNER JOIN time_report tr ON (t.task_id = tr.task_id " . $sqldata . ") ";
			$sqlM .= " INNER JOIN users u ON (tr.user_id=u.user_id AND u.is_viart=1) ";
			$sqlgroup = " GROUP BY tr.user_id ";			
			$db->query($sqlM . $sqlviart . $sqlgroup,__FILE__,__LINE__);
			while ($db->next_record()){
				$viart_users_time[$db->f(0)] = $db->f(1);
			}
			$db->query($sqlM . $sqlsayu . $sqlgroup,__FILE__,__LINE__);
			while ($db->next_record()){
				$sayu_users_time[$db->f(0)] = $db->f(1);
			}
			/**/
			/**/
			$sql  = " SELECT CONCAT(u.first_name, ' ', u.last_name) AS user_name, ";
			$sql .= " COUNT(DISTINCT DATE_FORMAT(tr.started_date, '%Y %m %d')) AS work_days ";
			$sql .= " FROM time_report tr, users u";
			$sql .= " WHERE WEEKDAY(tr.started_date)<=4 AND tr.user_id=u.user_id ".$sqlteam;
			$sql .= $sqldata;
			$sql .= " GROUP BY user_name ";
			$db->query($sql,__FILE__,__LINE__);
			//-- Number of work days that person worked during month
			$work_days = array();
			while ($db->next_record()) {
				$work_days[$db->f("user_name")] = $db->f("work_days");
			}

			$sql  = " SELECT u.user_id, CONCAT(mu.first_name, ' ', mu.last_name) AS manager_name, ";
			$sql .= " CONCAT(u.first_name, ' ', u.last_name) AS user_name, SUM(tr.spent_hours) AS count_hours, ut.team_name, ";
			$sql .= " COUNT(DISTINCT tr.task_id) AS count_tasks, COUNT(DISTINCT DATE_FORMAT(tr.started_date, '%Y %m %d')) AS working_days ";
			$sql .= " FROM (((users mu ";
			$sql .= " INNER JOIN users u ON (IF(u.manager_id>0,u.manager_id,u.user_id)=mu.user_id AND u.is_deleted is NULL)) ";
			$sql .= " INNER JOIN time_report tr ON (tr.user_id=u.user_id " . $sqldata . ")) ";
			$sql .= " LEFT JOIN users_teams ut ON (ut.manager_id=u.user_id)) ";
			$sql .= " WHERE 1 ".$sqlteam;
			$sql .= " GROUP BY user_name ";
			$sql .= " ORDER BY manager_name, u.manager_id, user_name ";
			$db->query($sql,__FILE__,__LINE__);

			if ($db->next_record()) {
				$t->set_var("no_records", "");
				$classrow = 0;
				$records = array();
				do {

					$user_name = $db->f("user_name");
					$manager_name = $db->f("manager_name");
					$user_id = $db->f("user_id");
					$count_hours = $db->f("count_hours");
					$count_tasks = $db->f("count_tasks");
					$team_users = $db->f("team_name");
					$user_viart_time = 0;
					$user_sayu_time = 0;
					$user_total_time = 0;
					
					$user_sayu_time = (isset($sayu_users_time[$user_id])?floatval($sayu_users_time[$user_id]):0) * $multiplier;
					if (isset($viart_total_time[0]) && $viart_total_time[0]>0 && isset($viart_users_time[$user_id])) {
						$user_viart_time = floatval($viart_users_time[$user_id]) * ($total_viart/$viart_total_time[0]);
					} else {
						$user_viart_time = 0;
					}
					$user_total_time = $user_sayu_time + $user_viart_time;
					
					if ($count_tasks != 0) {
						$time_per_task = $count_hours/$count_tasks; 
					} else { $time_per_task = 0;}
					//-- Number of days that person worked during month
					$working_days = $db->f("working_days");
					if ($working_days != 0) {
						$hours_per_day = $count_hours/$working_days;
					} else { $hours_per_day = 0;}
					$days_off = $db->f("working_days") - $work_days[$user_name];

				//begin warnings total
					$sql2 = "SELECT COUNT(user_id) AS warnings_total FROM warnings WHERE user_id='$user_id'";
					if ($year_selected) { $sql2 .= " AND DATE_FORMAT(date_added, '%Y')='$year_selected' ";}
					if ($month_selected) { $sql2 .= " AND DATE_FORMAT(date_added, '%m')='$month_selected' ";}
					//$sql2 .= "GROUP BY user_id";
					$warnings=0;
					$db2->query($sql2,__FILE__,__LINE__);
					if ($db2->next_record()) {
						$warnings = $db2->f("warnings_total");
					}
				//end warnings total

				//begin working hol
					$working_holidays = 0;
					$sql2 = "SELECT holiday_date FROM national_holidays ";
					if ($year_selected) { $sql2 .= " WHERE DATE_FORMAT(holiday_date, '%Y')='$year_selected' ";}
					if ($month_selected) { $sql2 .= " AND DATE_FORMAT(holiday_date, '%m')='$month_selected' ";}
					$db2->query($sql2,__FILE__,__LINE__);
					if ($db2->next_record()) {
						do {				
							//echo "1<br>";
							$hol_date = $db2->f("holiday_date");
							$sql3 = "SELECT report_id FROM time_report";
							$sql3 .=" WHERE user_id='$user_id' AND DATE_FORMAT(started_date, '%Y-%m-%d')='$hol_date'";
							$db3->query($sql3,__FILE__,__LINE__);
							if ($db3->next_record()) {
								$working_holidays = $working_holidays +1; //echo "1<br>";
							}
						} while ($db2->next_record());
					}
				//end working hol

				//begin holidays total
					$holidays_total = 0;
					$total_paid = 0;
					$sql2 = "SELECT * FROM days_off WHERE user_id='$user_id'";
					if ($year_selected) { $sql2 .= " AND DATE_FORMAT(start_date, '%Y')='$year_selected' ";}
					if ($month_selected) { $sql2 .= " AND DATE_FORMAT(start_date, '%m')='$month_selected' ";}
					//$sql2 .= "GROUP BY user_id";
					$db2->query($sql2,__FILE__,__LINE__);
					if ($db2->next_record()) {
						do {
							$reason = $db2->f("reason_id");
							$is_paid = $db2->f("is_paid");
							//PAID DAYS

							$start_date = $db2->f("start_date");
							$start_date_arr = explode("-", $start_date);
							$end_date = $db2->f("end_date");
							$end_date_arr = explode("-", $end_date);
							// if holidays begin and end in this month
							if ($end_date_arr[1]==$month_selected) {
									$holidays_total = $holidays_total + $db2->f("total_days");
									if (($reason==1) || ($reason==2) || ($is_paid==1)) {
										$total_paid =  $total_paid + $db2->f("total_days");
									}
							} else {
								//if holidays begin in this month but end in next
								$n_days = date("t", mktime(0, 0, 0, $month_selected, 1, $year_selected));
								$holidays_total = $holidays_total + ($n_days-$start_date_arr[2]+1);
								if (($reason==1) || ($reason==2) || ($is_paid==1)) {
									$total_paid =  $total_paid + $n_days - $start_date_arr[2]+1;
								}
							}
						} while ($db2->next_record());
						
					} else {
						//if holidays begin in the previos month but last fo this
						$sql2 = "SELECT * FROM days_off WHERE user_id='$user_id'";
						if ($year_selected) { $sql2 .= " AND DATE_FORMAT(end_date, '%Y')='$year_selected' ";}
						if ($month_selected) { $sql2 .= " AND DATE_FORMAT(end_date, '%m')='$month_selected' ";}
						//	$sql2 .= "GROUP BY user_id";
						$holidays_total=0;
						$db2->query($sql2,__FILE__,__LINE__);
						if ($db2->next_record()) {
						 	do {
						 	  	$reason = $db2->f("reason_id");
								$is_paid = $db2->f("is_paid");
								$start_date = $db2->f("start_date");
								$start_date_arr = explode("-", $start_date);
								$end_date = $db2->f("end_date");
								$end_date_arr = explode("-", $end_date);
								$holidays_total = $holidays_total + $end_date_arr[2];
								if (($reason==1) || ($reason==2) || ($is_paid==1))
								$total_paid =  $total_paid + $end_date_arr[2];
							}
							while ($db2->next_record());
						}
					}
				//end holidays total
				
					//$t->set_var("classrow",(($classrow++)%2 == 1)?"DataRow2":"DataRow3");
					/*/
					if ($manager_name == $user_name) {
						$t->set_var("team_name", $team_users);
						$t->parse("teamname",true);
						$t->set_var("user_name", $user_name);
						$t->set_var("class_user","manager_name");
					} else {
						$t->set_var("teamname","");
						$t->set_var("class_user","user_name");
						$t->set_var("user_name", $user_name);
					}
					/**/
					if (isset($records[1]) && strlen($team_users)) {
						//var_dump($records);echo"\r\n";
						
						parse_records();
						unset($records);
						
						$records = array();
						clear_records();
						
						$record["warnings"]			= $warnings;
						$record["holidays_total"]	= $holidays_total;
						$record["total_paid"]		= $working_days + $total_paid;
						$record["user_id"]			= $user_id;
						$record["user_name"]		= $user_name;
						$record["manager_name"]		= $manager_name;
						$record["spent_hours"]		= $count_hours;
						$record["tasks"]			= $count_tasks;
						$record["time_per_task"]	= $time_per_task;
						$record["hours_per_day"]	= $hours_per_day;
						$record["working_days"]		= $working_days;
						$record["days_off"]			= $days_off;
						$record["working_holidays"]	= $days_off + $working_holidays;
						$record["year_selected"]	= $year_selected;
						$record["month_selected"]	= $month_selected;
						$record["viart_projects"]	= $user_viart_time;
						$record["sayu_projects"]	= $user_sayu_time;
						$record["total_projects"]	= $user_total_time;
						
						if ($manager_name == $user_name) { $records[0]["user_name"] = $team_users;}
						update_into_records($record);
						array_push($records, $record);
					} else {
						if (!sizeof($records)) {
							clear_records();
						}
						
						$record["warnings"]			= $warnings;
						$record["holidays_total"]	= $holidays_total;
						$record["total_paid"]		= $working_days + $total_paid;
						$record["user_id"]			= $user_id;
						$record["user_name"]		= $user_name;
						$record["manager_name"]		= $manager_name;
						$record["spent_hours"]		= $count_hours;
						$record["tasks"]			= $count_tasks;
						$record["time_per_task"]	= $time_per_task;
						$record["hours_per_day"]	= $hours_per_day;
						$record["working_days"]		= $working_days;
						$record["days_off"]			= $days_off;
						$record["working_holidays"]	= $days_off + $working_holidays;
						$record["year_selected"]	= $year_selected;
						$record["month_selected"]	= $month_selected;
						$record["viart_projects"]	= $user_viart_time;
						$record["sayu_projects"]	= $user_sayu_time;
						$record["total_projects"]	= $user_total_time;
						
						if ($manager_name == $user_name) { $records[0]["user_name"] = $team_users;}
						update_into_records($record);
						array_push($records, $record);
					}
				} while ($db->next_record());
				parse_records();
				unset($records);
			}
			else
			{
				$t->set_var("records_header", "");
				$t->set_var("records", "");
				$t->set_var("teamname", "");
				$t->set_var("team_group", "");
				$t->parse("no_records", false);
			} //if ($db->next_record())

			$t->set_var("bonuses", "");
			$t->set_var("penalties", "");

			$t->parse("result", false);
		}
		else {
			$t->set_var("result", "");
			echo "<font style=\"font-size:12pt; color:#ff0000; font-weight:bold\"><center>Enter search criteria, please</center></font>";
		}//if ($year_selected && $month_selected)
	}
	else {
		$t->set_var("result", "");
	} // if ($submit)

	if($submit && $year_selected && $month_selected && $person_selected && is_number($person_selected)){
		$sql = " SELECT DAYOFMONTH(tr.started_date) AS day_of_month, SUM(tr.spent_hours) AS sum_hours, ";
		$sql .= " CONCAT(u.first_name, ' ', u.last_name) AS user_name ";
		$sql .= " FROM time_report tr, users u ";
		$sql .= " WHERE tr.user_id='$person_selected' AND tr.user_id=u.user_id ";
		$sql .= " AND DATE_FORMAT(tr.started_date, '%Y')='$year_selected' ";
		$sql .= " AND DATE_FORMAT(tr.started_date, '%m')='$month_selected' ";
		$sql .= " GROUP BY day_of_month ";
		$db->query($sql,__FILE__,__LINE__);

		//-- Days when person worked
		$attended_dates = array();
		$spent_hours = array();
		while ($db->next_record()) {
			$attended_dates[$db->f("day_of_month")] = 1;
			$spent_hours[$db->f("day_of_month")] = $db->f("sum_hours");
			$user_name = $db->f("user_name");
			$t->set_var("user_name", $user_name);
		}

//for holidays
		$sql = " SELECT holiday_date FROM national_holidays ";
		$sql .= " WHERE DATE_FORMAT(holiday_date, '%Y')='$year_selected' ";
		$sql .= " AND DATE_FORMAT(holiday_date, '%m')='$month_selected' ";
		$db->query($sql,__FILE__,__LINE__);
		while ($db->next_record()) {			$holiday_date = $db->f("holiday_date");
		  	$holiday_date_arr = explode("-",$holiday_date);
		  	$day_of_hol = (integer)$holiday_date_arr[2];
			$holiday_dates[$day_of_hol] = 1;		}
		/*
		if  ($db->next_record()){			do {
		  		$holiday_date = $db->f("holiday_date");
		  		$holiday_date_arr = explode("-",$holiday_date);
		  		$day_of_hol = (integer)$holiday_date_arr[2];

				$holiday_dates[$day_of_hol] = 1;
			} while ($db->next_record());

		}
		*/
///end for holidays

		//-- Number of day in month
		$n_days = date("t", mktime(0, 0, 0, $month_selected, 1, $year_selected));
		//-- First day of month 1..7 - Monday..Sunday
		$first_day = date("w", mktime(0, 0, 0, $month_selected, 1, $year_selected));
		if ($first_day == 0) $first_day = 7;
		//-- Number of weeks in month, even with only 1 day
		//$n_weeks = date("W", mktime(0, 0, 0, $month_selected, $n_days, $year_selected)) - date("W", mktime(0, 0, 0, $month_selected, 1, $year_selected)) + 1;
		$week_last_day = 1+(date("z", mktime(0, 0, 0, $month_selected, $n_days, $year_selected))+1)/7;
		$week_first_day = 1+(date("z", mktime(0, 0, 0, $month_selected, 1, $year_selected))+1)/7;
		$n_weeks = floor($week_last_day) - floor($week_first_day) + 1;
		if ($n_weeks < 0) $n_weeks += date("W", mktime(0, 0, 0, $month_selected, 1, $year_selected));
		
		/**/
		$_first_day = $first_day;
		$_n_days = $n_days - (8 - $_first_day);// day of first week
		$_short_week = $_n_days % 7;// day of last week
		$_full_week = $_n_days - $_short_week;
		$_total_weeks = 1 + $_full_week/7 + ($_short_week?1:0);
		$n_weeks = $_total_weeks;
		/**/

		$cur_day = 1;
		$week_hours = 0;
		$month_hours = 0;
		$w_working_days = 0;
		for ($row = 1; $row <= $n_weeks; $row++) {
			for ($col = 1; $col <= 7; $col++) {
				if (($row == 1 && $col >= $first_day) || ($row > 1 && $cur_day <=$n_days)) {
					$sd = date ("Y-m-d", mktime (0, 0, 0, $month_selected, $cur_day, $year_selected));
					$link = "<a href=\"time_report.php?submit=1&person_selected=$person_selected&start_date=$sd&end_date=$sd\">$cur_day</a>";
					$t->set_var("day".$col, $link);
					if (isset($attended_dates[$cur_day]) && $attended_dates[$cur_day] == 1) {
					  	if ($holiday_dates[$cur_day]) $t->set_var("day_color".$col, "#EECF63");
						else $t->set_var("day_color".$col, "#7FC5F4");
						$week_hours += $spent_hours[$cur_day];
						$w_working_days++;
					}
					elseif ($holiday_dates[$cur_day]) {$t->set_var("day_color".$col, "#EECF63"); $cur_day++; continue;}
					elseif ($col > 5) $t->set_var("day_color".$col, "#C5F4C5");
					else $t->set_var("day_color".$col, "#FAFAFA");
					$cur_day++;
				}
				else {
				 	$t->set_var("day".$col, "");
				 	$t->set_var("day_color".$col, "#FAFAFA");
			 	}
				if ($col == 7) {
				 	$t->set_var("week_hours", Hours2HoursMins($week_hours));
				 	$t->set_var("week_color", "#FAFAFA");
				 	if ($w_working_days != 0) $w_hours_per_day = $week_hours/$w_working_days; else $w_hours_per_day = 0;
				 	$t->set_var("w_hours_per_day", Hours2HoursMins($w_hours_per_day));
				 	$month_hours += $week_hours;
					$week_hours = 0;
					$w_working_days = 0;
				}
			}
			$t->parse("week", true);
			$t->set_var("month_hours", Hours2HoursMins($month_hours));
		}

		$t->parse("calendar", false);
	}
	else {
		$t->set_var("calendar", "");
	} //if

	$t->pparse("main");
	
function update_into_records($record)
{
	global $records;
	
	$records[0]["warnings"]			+= $record["warnings"];
	$records[0]["holidays_total"]	+= $record["holidays_total"];
	$records[0]["total_paid"]		+= $record["total_paid"];
	$records[0]["spent_hours"]		+= $record["spent_hours"];
	$records[0]["tasks"]			+= $record["tasks"];
	$records[0]["time_per_task"]	+= $record["time_per_task"];
	$records[0]["hours_per_day"]	+= $record["hours_per_day"];
	$records[0]["working_days"]		+= $record["working_days"];
	$records[0]["days_off"]			+= $record["days_off"];
	$records[0]["working_holidays"]	+= $record["working_holidays"];
	$records[0]["viart_projects"]	+= $record["viart_projects"];
	$records[0]["sayu_projects"]	+= $record["sayu_projects"];
	$records[0]["total_projects"]	+= $record["total_projects"];
}

function clear_records()
{
	global $records;
	
	$record["warnings"]			= 0;
	$record["holidays_total"]	= 0;
	$record["total_paid"]		= 0;
	$record["user_id"]			= 0;
	$record["user_name"]		= "";
	$record["spent_hours"]		= 0;
	$record["tasks"]			= 0;
	$record["time_per_task"]	= 0;
	$record["hours_per_day"]	= 0;
	$record["working_days"]		= 0;
	$record["days_off"]			= 0;
	$record["working_holidays"]	= 0;
	$record["year_selected"]	= 0;
	$record["month_selected"]	= 0;
	$record["viart_projects"]	= 0;
	$record["sayu_projects"]	= 0;
	$record["total_projects"]	= 0;
	$records[0] = $record;
	//
}

function parse_records()
{
	global $t, $records;
	
	$t->set_var("classrow","DataRow2");
	$t->set_var("team_warnings", $records[0]["warnings"]);
	$t->set_var("team_working_days_planned","");
	$t->set_var("team_holidays_total", $records[0]["holidays_total"]);
	$t->set_var("team_total_paid", $records[0]["total_paid"]);
	$t->set_var("team_name", $records[0]["user_name"]);
	$t->set_var("team_spent_hours", Hours2HoursMins($records[0]["spent_hours"]));
	$t->set_var("team_tasks", $records[0]["tasks"]);
	$t->set_var("team_time_per_task", Hours2HoursMins($records[0]["time_per_task"]/(sizeof($records)-1)));
	//$t->set_var("team_time_per_task", "");
	$t->set_var("team_hours_per_day", Hours2HoursMins($records[0]["hours_per_day"]/(sizeof($records)-1)));
	//$t->set_var("team_hours_per_day", "");
	$t->set_var("team_working_days", $records[0]["working_days"]);
	$t->set_var("team_days_off", $records[0]["days_off"]);
	$t->set_var("team_working_holidays", $records[0]["working_holidays"]);
	$t->set_var("team_year_selected", $records[0]["year_selected"]);
	$t->set_var("team_month_selected", $records[0]["month_selected"]);
	$t->set_var("team_viart_projects",number_format($records[0]["viart_projects"],2));
	$t->set_var("team_sayu_projects",number_format($records[0]["sayu_projects"],2));
	$t->set_var("team_total_projects",number_format($records[0]["total_projects"],2));
	$t->parse("teamname",true);
	unset($records[0]);
	foreach($records as $k => $record) {
		$t->set_var("classrow","DataRow1");
		if ($record["manager_name"] == $record["user_name"]) {
			$t->set_var("class_user","manager_name");
		} else { $t->set_var("class_user","user_name");}
		$t->set_var("warnings", $record["warnings"]);
		$t->set_var("holidays_total", $record["holidays_total"]);
		$t->set_var("total_paid", $record["total_paid"]);
		$t->set_var("user_id", $record["user_id"]);
		$t->set_var("user_name", $record["user_name"]);
		$t->set_var("spent_hours", Hours2HoursMins($record["spent_hours"]));
		$t->set_var("tasks", $record["tasks"]);
		$t->set_var("time_per_task", Hours2HoursMins($record["time_per_task"]));
		$t->set_var("hours_per_day", Hours2HoursMins($record["hours_per_day"]));
		$t->set_var("working_days", $record["working_days"]);
		$t->set_var("days_off", $record["days_off"]);
		$t->set_var("working_holidays", $record["working_holidays"]);
		$t->set_var("year_selected", $record["year_selected"]);
		$t->set_var("month_selected", $record["month_selected"]);
		$t->set_var("viart_projects",number_format($record["viart_projects"],2));
		$t->set_var("sayu_projects",number_format($record["sayu_projects"],2));
		$t->set_var("total_projects",number_format($record["total_projects"],2));
		
		$t->parse("records", true);
	}
	$t->parse("team_group",true);
	$t->set_var("teamname","");
	$t->set_var("records", "");
}
?>