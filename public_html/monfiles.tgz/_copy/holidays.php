<?php

include ("./includes/common.php");
include ("./includes/date_functions.php");

$db2 = new DB_Sql;
$db2->Database = DATABASE_NAME;
$db2->User     = DATABASE_USER;
$db2->Password = DATABASE_PASSWORD;
$db2->Host     = DATABASE_HOST;

if (getsessionparam("privilege_id") == 9) {
	header("Location: index.php");
	exit;
}

$type = strtolower(getparam("type"));
if (!$type) {
	$type = "ukrainian";
}



$T = new iTemplate("./templates", array("page"=>"holidays.html"));

$T->set_var("type", $type);

if ($type == "english") {
	$holidays_table = "english_holidays";
	$T->set_var("country", "English");
} else {
	$holidays_table = "national_holidays";
	$T->set_var("country", "Ukrainian");
}
	
$sql = "SELECT * FROM " . $holidays_table . " ORDER BY holiday_date";
$db->query($sql);
if ($db->next_record()) {
	do {
		$holiday_id = $db->Record["holiday_id"];
		$T->set_var("holiday_id",    $holiday_id);
		$T->set_var("holiday_title", $db->Record["holiday_title"]);
    	$T->set_var("holiday_date",  date("jS F Y", strtotime($db->Record["holiday_date"])));
    	$T->parse("holiday_rows", true);
	} while ($db->next_record()); 
	$T->parse ("holiday_header");
	$T->set_var("holiday_error","");	
} else {
	$T->set_var("holiday_rows",   "");
	$T->set_var("holiday_header", ""); 
	$T->parse("holiday_error");
}

//$h_id = GetParam("holiday_id");
$add = GetParam("add");
if ($add) {
	$this_year = date('Y') + 1;
	$sql = "SELECT * FROM holiday_template ORDER BY holiday_date";
	$db->query($sql);
	while ($db->next_record()){
		$h_id = $db->Record["holiday_id"];
		$sql2 = "SELECT * FROM " . $holidays_table . " WHERE holiday_id=$h_id AND YEAR(holiday_date)>=" . $this_year;
		$db2->query($sql2);
		if (!$db2->next_record()) {
			$h_t  = $db->Record["holiday_title"];
			$h_d  = $db->Record["holiday_date"];
			if (!$h_d || $h_d == '0000-00-00') {
				$sql2 = "SELECT * FROM " . $holidays_table . " WHERE holiday_id=$h_id LIMIT 0,1";
				$db2->query($sql2);
				if ($db2->next_record()) {
					$h_d  = $db2->Record["holiday_date"];
				}
			}
			if (!$h_d || $h_d == '0000-00-00') continue;
			$arr_h_d      = explode("-", $h_d);
			$holiday_date = $this_year . "-" . $arr_h_d[1] . "-" . $arr_h_d[2];
			$sql2  = " UPDATE " . $holidays_table . " SET holiday_id=holiday_id+YEAR(holiday_date) * 100 WHERE holiday_id=" . $h_id;
			$db2->query($sql2);			
			$sql2  = " INSERT INTO " . $holidays_table . " (holiday_id, holiday_title, holiday_date) ";
			$sql2 .= " VALUES ('$h_id', ". ToSQL($h_t, STRING) . ", '$holiday_date')";
			$db2->query($sql2);
			echo $sql2 . '<br>';
		}
	}
	header("Location: holidays.php");
}

if ($type=="english") {
	$T->set_var("template_holidays", "");
} else {
	$T->parse("template_holidays", false);
}

$T->pparse("page", false);

?>