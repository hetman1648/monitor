<?php

	include_once ("./includes/common.php");

	header("Cache-Control: private");
	header("Age: 699");

	define("CHANGE_PERM", 4);
		
	if (getsessionparam("privilege_id") == PRIV_CUSTOMER) {
		header("Location: index.php");
		exit;
	}

	CheckSecurity(2);

	$sFileName			= "edit_project.php";
	$sTemplateFileName	= "edit_project.html";

	$T = new iTemplate($sAppPath,array("main"=>$sTemplateFileName));

	$T->set_var("FileName", $sFileName);

	$sFormErr	= "";

	$sAction	= GetParam("FormAction");
	$sForm		= GetParam("FormName");
	$project_id	= GetParam("project_id");
	$return_page= GetParam("return_page");

	if ($sForm=="Form") {
		FormAction($sAction);
	}

	$assigned = array();
	if ($project_id) {
		count_project_time($project_id);
	  	$sql  = " SELECT user_id, permissions ";
	  	$sql .= " FROM users_projects WHERE project_id=" . ToSQL($project_id,"integer",false);
		$db->query($sql);
		while ($db->next_record()) {
	  		$assigned[$db->f("user_id")] = $db->f("permissions");
		}
	}

	$users_array = array();
	$users_rows = array();
	$user_in_project = array();
	//users/projects
	$sql = " SELECT p.project_id, t.task_id, t.created_person_id, t.responsible_user_id ";
	$sql.= " FROM projects p ";
	$sql.= " INNER JOIN tasks t ON (p.project_id=t.project_id AND DATE_ADD(t.creation_date, INTERVAL 6 MONTH)>=NOW()) ";
	$sql.= " WHERE p.project_id=".ToSQL($project_id, "integer");
	$sql.= " GROUP BY t.created_person_id, t.responsible_user_id ";
	$db->query($sql);
	while ($db->next_record()) {
		$user_in_project[$db->f("created_person_id")] = 1;
		$user_in_project[$db->f("responsible_user_id")] = 1;
	}
	
	$sql = " SELECT p.project_id, t.task_id, m.user_id, m.responsible_user_id ";
	$sql.= " FROM projects p ";
	$sql.= " INNER JOIN tasks t ON p.project_id=t.project_id ";
	$sql.= " INNER JOIN messages m ON (t.task_id = m.identity_id AND m.identity_type='task' AND DATE_ADD(m.message_date, INTERVAL 6 MONTH)>=NOW()) ";
	$sql.= " WHERE p.project_id=".ToSQL($project_id, "integer");
	$sql.= " GROUP BY m.user_id, m.responsible_user_id ";
	$db->query($sql);
	while ($db->next_record()) {
		$user_in_project[$db->f("user_id")] = 1;
		$user_in_project[$db->f("responsible_user_id")] = 1;
	}
	
	$sql = " SELECT p.project_id, t.task_id, tr.user_id ";
	$sql.= " FROM projects p ";
	$sql.= " INNER JOIN tasks t ON p.project_id=t.project_id ";
	$sql.= " INNER JOIN time_report tr ON (t.task_id = tr.task_id AND DATE_ADD(tr.report_date, INTERVAL 6 MONTH)>=NOW()) ";
	$sql.= " WHERE p.project_id=".ToSQL($project_id, "integer");
	$sql.= " GROUP BY tr.user_id ";
	$db->query($sql);
	while ($db->next_record()) {
		$user_in_project[$db->f("user_id")] = 1;
	}	
	
	//-- sayu users
	$sql = " SELECT user_id, is_viart, privilege_id, IF (manager_id>=1, manager_id, 0) AS manager, CONCAT(first_name,' ',last_name) as user_name ";
	$sql.= " FROM users WHERE (is_deleted IS NULL OR is_deleted=0) AND (is_viart=0 OR is_viart IS NULL) ORDER BY user_name ASC";
	$db->query($sql);	
	while($db->next_record()) {
		$user_id   = $db->f("user_id");
		$user_name = $db->f("user_name");
		if (isset($user_in_project[$user_id])) {
			$user_name = "<b>".$user_name."<b>";
		}
		$checked = "";
		$steps_checked = "";
		if (array_key_exists($user_id, $assigned)) {
			$checked = "checked";
			$steps_checked = "steps_checked";
			$permissions = $assigned[$user_id];
			if ($permissions&CHANGE_PERM) {
				$steps_checked = "checked";
			}
		}
		
		$user = array("user_id"=>$user_id, "user_name"=>$user_name, "checked"=>$checked, "steps_checked" => $steps_checked);
		$T->set_var($user);
		$T->parse("sayu_user_control", true);
	}
	
	//viart users
			
	$sql  = " SELECT t.manager_id, t.team_name, COUNT(u.user_id) AS users_count ";
	$sql .= " FROM (users_teams t ";
	$sql .= " LEFT JOIN users u ON (u.manager_id = t.manager_id OR u.user_id = t.manager_id))";
	$sql .= " WHERE (u.is_deleted IS NULL OR u.is_deleted =0)";
	$sql .= " GROUP BY t.team_id ";
	$sql .= " ORDER BY t.team_name";
	$db->query($sql);
	$teams = array();
	while ($db->next_record()) {
		$users_count = $db->f("users_count");
		if ($users_count > 0) {
			$manager_id = (int)$db->f("manager_id");	
			$teams[$manager_id]['title'] = $db->f("team_name");
		}
	}
	
	
	$sql  = " SELECT user_id, manager_id, CONCAT( first_name, ' ', last_name ) AS user_name ";
	$sql .= " FROM users";
	$sql .= " WHERE (is_deleted IS NULL OR is_deleted=0) AND is_viart =1";
	$sql .= " ORDER BY user_name";
	$db->query($sql);	
	while ($db->next_record()) {
		if ($db->f('manager_id') > 0) {
			$teams[$db->f('manager_id')]['users'][$db->f('user_id')] = $db->f('user_name');
		}	
		if (isset($teams[$db->f('user_id')])) {
			$teams[$db->f('user_id')]['users'][$db->f('user_id')] = $db->f('user_name');
		}	
	}
		
	if ($teams) {
		foreach ($teams AS $manager_id => $params) {
			$T->set_var("user_control", "");
			$T->set_var("team_name",    isset($params['title']) ? $params['title'] : 'NONAME ' . $manager_id);
			if ($params['users']) {
				foreach ($params['users'] AS $user_id => $user_name) {
					if (isset($user_in_project[$user_id])) {
						$user_name = "<b>" . $user_name . "</b>";
					}
					$checked       = "";
					$steps_checked = "";
					if (array_key_exists($user_id, $assigned)) {
						$checked = "checked";
						$permissions = $assigned[$user_id];
						if ($permissions&CHANGE_PERM) {
							$steps_checked = "checked";
						}
					}
					$user = array(
						"user_id"       => $user_id,
						"user_name"     => $user_name,
						"checked"       => $checked,
						"steps_checked" => $steps_checked
					);
					$T->set_var($user);
					$T->parse("user_control", true);
				}
			}
			$T->parse("user_team");
		}
	}
		
	Form_Show();
	$T->set_var("return_page",$return_page);

	$T->parse("main", false);
	echo $T->p("main");

//********************************************************************************

function FormAction($sAction)
{
	global $db;
	global $T;
	global $sAction;
	global $sForm;
	global $sFormErr;
	global $return_page;
	$sParams = "";

	$sActionFileName = "index.php";
	if ($return_page) {$sActionFileName = $return_page;}


	$sWhere = "";
	$bErr	= false;

	if($sAction == "cancel"){header("Location: " . $sActionFileName);}
	if($sAction == "update" || $sAction == "delete") {
		$pPKproject_id = GetParam("PK_project_id");
		$sWhere .= "project_id=" . ToSQL($pPKproject_id, "Number");
	}
	switch(strtolower($sAction)):
	    case "insert":
		    $sSQL = "INSERT INTO projects (" .
		        "parent_project_id," .
		        "project_title," .
		        "emails_copy," .
		        "project_desc," .
		        "project_status_id," .
		        "responsible_user_id, " .
				"project_url, client_id, is_closed, is_domain_required, cvs_module)" .
		        " values (";
		    if (GetParam("parent_project_id")>0) {$sSQL.="".ToSQL(GetParam("parent_project_id"), "Number")  . ",";}
		      else {$sSQL.=" NULL,";}
		    $sSQL.= " ". ToSQL(GetParam("project_title"), "Text")  . "," .
						ToSQL(GetParam("emails_copy"), "Text")  . "," .
						ToSQL(GetParam("project_desc"), "Text")  . "," .
						ToSQL(GetParam("project_status_id"), "Number")  . "," .
						ToSQL(GetParam("responsible_user_id"), "Number")  . ",".
						ToSQL(GetParam("project_url"), "text")  . ",".
						ToSQL(GetParam("client_id"), "Number") . ", ".
						ToSQL(GetParam("is_closed"), "Number",false) . "," .
						ToSQL(GetParam("is_domain_required"), "Number", false) . "," .
						ToSQL(GetParam("cvs_module"), "text")  . ")";
		    $db->query($sSQL);

		    //-- determine last inserted id
		    $db->query("SELECT LAST_INSERT_ID()");
		    if ($db->next_record()) {
				$id = $db->f(0);
			}

		    add_assigned_people($id);

		    $tags = array (	"PROJECT_TITLE" => GetParam("project_title"),
							"URL"			=> getenv("SCRIPT_URI")."?project_id=".$id,
							"project_id"	=> $id
		               );
		    send_enotification(MSG_PROJECT_CREATED,$tags);
	    break;

	    case "update":
			$sSQL = "UPDATE projects SET " .
					"project_title	=" . ToSQL(GetParam("project_title"), "Text") .
					",emails_copy	=" . ToSQL(GetParam("emails_copy"), "Text") .
					",project_desc	=" . ToSQL(GetParam("project_desc"), "Text") .
					",project_url	=" . ToSQL(GetParam("project_url"), "Text") .
					",client_id		=" . ToSQL(GetParam("client_id"), "Number") .
					",is_closed		=" . ToSQL(GetParam("is_closed"), "Number") .
					",is_domain_required =" . ToSQL(GetParam("is_domain_required"), "Number", false) .
					",project_status_id =" . ToSQL(GetParam("project_status_id"), "Number") .
					",cvs_module =" . ToSQL(GetParam("cvs_module"), "Text");
			if (GetParam("parent_project_id")>0) {$sSQL.=",parent_project_id=" . ToSQL(GetParam("parent_project_id"), "Number");}
			 else {$sSQL.=",parent_project_id=NULL ";}
			$sSQL .= ",responsible_user_id=" . ToSQL(GetParam("responsible_user_id"), "Number");
			$sSQL .= " where " . $sWhere;
			$db->query($sSQL);
			add_assigned_people($pPKproject_id);
	    break;

	    case "delete":
			$sSQL = "delete from projects where " . $sWhere;
			$db->query($sSQL);
	    break;

	    case "addsub":
			$sSQL  = "INSERT INTO projects (project_title, emails_copy, parent_project_id, project_status_id, responsible_user_id,project_url, client_id) ";
			$sSQL .= "VALUES ( ".ToSQL(GetParam("subproject_title"),"Text").", ".ToSQL(GetParam("emails_copy"),"Text").", ";
			$sSQL .= ToSQL(GetParam("project_id"), "Number").", 1, ".ToSQL(GetParam("responsible_user_id"), "Number").", ";
			$sSQL .= ToSQL(GetParam("project_url"), "Text").", ".ToSQL(GetParam("client_id"), "Number") . ")";
			$db->query($sSQL);
			$db->query("SELECT LAST_INSERT_ID()");
			$db->next_record();
			$new_id=$db->f("0");
			add_assigned_people($new_id);
	   break;

	  endswitch;

	header("Location: " . $sActionFileName);
}

function Form_Show()
{
	global $db;
	global $T;
	global $sAction;
	global $sForm;
	global $sFormErr;

	$sWhere = "";

	$bPK				= true;
	$fldproject_title	= "";
	$fldemails_copy		= "";
	$fldcvs_module      = "";
	$fldproject_desc	= "";
	$fldis_closed	    = 0;
	$fldis_domain_required = 0;
	$fldproject_id		= "";
	$fldproject_url		= "";
	$fldclient_name		= "";
	$fldproject_status_id	= "";
	$fldresponsible_user_id = "";
	$fldparent_project_id	= "";
	$fldclient_id = 0;
	$ifp = 0;

	if ($sAction != "" && $sForm == "Form") {
		$fldproject_title		= stripslashes(GetParam("project_title"));
		$fldemails_copy			= stripslashes(GetParam("emails_copy"));
		$fldcvs_module			= stripslashes(GetParam("cvs_module"));
		$fldproject_desc		= stripslashes(GetParam("project_desc"));
		$fldproject_status_id	= stripslashes(GetParam("project_status_id"));
		$fldresponsible_user_id	= stripslashes(GetParam("responsible_user_id"));
		$fldproject_id			= stripslashes(GetParam("project_id"));
		$fldproject_url			= stripslashes(GetParam("project_url"));
		$fldclient_id			= stripslashes(GetParam("client_id"));
		$fldis_closed			= stripslashes(GetParam("is_closed"));
		$fldis_domain_required	= stripslashes(GetParam("is_domain_required"));
		$pproject_id			= GetParam("PK_project_id");
	} else {
		$pproject_id 			= GetParam("project_id");
	}


	if(strlen($pproject_id)) {
		$sWhere .= "p.project_id=" . ToSQL($pproject_id, "Number");
		$T->set_var("PK_project_id", $pproject_id);
	} else {$bPK = false;}

	$sSQL  = "SELECT * FROM (projects p ";
	$sSQL .= " LEFT JOIN clients c ON (c.client_id = p.client_id))";
	$sSQL .= " WHERE " . $sWhere;

	if($bPK && $sAction != "insert") {
		$db->query($sSQL);
		$db->next_record();
		if($sAction == "") {
			$fldproject_title	= GetValue($db, "project_title");
			$fldemails_copy		= GetValue($db, "emails_copy");
			$fldcvs_module		= GetValue($db, "cvs_module");
			$fldproject_desc	= GetValue($db, "project_desc");
			$fldis_closed		= GetValue($db, "is_closed");
			$fldis_domain_required = GetValue($db, "is_domain_required");
			$fldproject_id		= GetValue($db, "project_id");
			$fldproject_url		= GetValue($db, "project_url");
			$fldclient_id		= GetValue($db, "client_id");
			$fldclient_name		= GetValue($db, "client_name");
			$fldparent_project_id	= GetValue($db, "parent_project_id");
			$fldresponsible_user_id = GetValue($db, "responsible_user_id");
			$fldproject_status_id	= GetValue($db, "project_status_id");
		}
		$T->set_var("FormInsert", "");
		$T->parse("FormEdit", false);
		$T->parse("FormCancel", false);
	} else {
		$T->set_var("FormEdit", "");
		$T->parse("FormInsert", false);
		$T->parse("FormCancel", false);
	}

	$T->set_var("project_title", ToHTML($fldproject_title));
	$T->set_var("this_client_name", ToHTML($fldclient_name));

	$parentsql="SELECT project_id, project_title, parent_project_id FROM projects WHERE parent_project_id IS NULL AND project_title!='' ";
	if($fldproject_id>0) {$parentsql.=" AND project_id!=$fldproject_id ";}
	$parentsql.="ORDER BY project_title";

	$db->query($parentsql);
	if ($fldparent_project_id<1) {$T->set_var("TopProjSelected","SELECTED");}
	 else {$T->set_var("TopProjSelected","");}
	while($db->next_record()) {
		$T->set_var("ID", $db->f(0));
		$T->set_var("Value", $db->f(1));
		if($db->f(0) == $fldparent_project_id) {$T->set_var("Selected", "SELECTED" );}
		else {$T->set_var("Selected", "");}
		$T->parse("LBparent_project", true);
	}

	$T->set_var("emails_copy", ToHTML($fldemails_copy));
	$T->set_var("cvs_module", ToHTML($fldcvs_module));
	$T->set_var("project_desc", ToHTML($fldproject_desc));
	$T->set_var("project_url", ToHTML($fldproject_url));
	$T->set_var("this_client_id", (strlen($fldclient_id)?$fldclient_id:0));
	if ($fldis_closed) {
		$T->set_var("is_closed_checked", "checked");
	} else {
		$T->set_var("is_closed_checked", "");
	}
	if ($fldis_domain_required) {
		$T->set_var("is_domain_required_checked", "checked");
	} else {
		$T->set_var("is_domain_required_checked", "");
	}

	$sublist="";
	if ($fldproject_id>0) {
		$sql = "SELECT total_time AS total_hours
	    		FROM projects
	    		WHERE project_id=$fldproject_id";
	    
		$db->query($sql);
		if ($db->next_record()){
			$totaltime = $db->Record["total_hours"];
			$totaltime = floor($totaltime) . ":" . sprintf("%02d", round(($totaltime - floor($totaltime)) * 60));
			$T->set_var("total_time", ToHTML($totaltime));
		} else {
			$T->set_var("total_time", "");
		}

		$db->query("SELECT project_title FROM projects WHERE parent_project_id=".$fldproject_id." ORDER BY project_title");
		while ($db->next_record()) {$sublist.=($db->f("project_title"))."<BR>";}

		$db->query("SELECT IF(parent_project_id IS NULL, 1, 0) AS ifp FROM projects WHERE project_id=".$fldproject_id);
		$db->next_record();
		$ifp = $db->f("ifp");
    } else {
    	$T->set_var("total_time", "");
    }

	if (strlen($sublist)) {$T->set_var("ParentTR","");}
	 else $T->parse("ParentTR",false);

	$T->set_var("SubprojectsList",$sublist);
	if ($ifp) {$T->parse("SubprojectsTR",false);}
	 else {$T->set_var("SubprojectsTR","");}

	if ($fldparent_project_id) {
		$status_project_id = $fldparent_project_id;
	} else {
		$status_project_id = $fldproject_id;
	}
	 
	get_select_options("projects_statuses", "project_status_id", "status_desc", $fldproject_status_id,
			"WHERE parent_project_id=".ToSQL($status_project_id, "integer"), 
			"status_order ASC", "", "", "project_status_id", array("0"=>"-- please select status --"));
	$T->set_var("status_project_id", $status_project_id);
	
	$T->set_var("LBresponsible_user_id", "");

	$db->query("SELECT user_id, first_name,last_name FROM users WHERE is_deleted IS NULL AND privilege_id=".PRIV_PM." order by 2");
	while($db->next_record()) {
		$T->set_var("ID", $db->f(0));
		$T->set_var("Value", $db->f(1)." ".$db->f(2));
		if($db->f(0) == $fldresponsible_user_id) {$T->set_var("Selected", "SELECTED" );}
		 else {$T->set_var("Selected", "");}
		$T->parse("LBresponsible_user_id", true);
	}

	$T->set_var("project_id", ToHTML($fldproject_id));
	if($sFormErr == "") {$T->set_var("FormError", "");}
	 else {
		$T->set_var("sFormErr", $sFormErr);
		$T->parse("FormError", false);
	}
	$T->parse("FormForm", false);
}

function add_assigned_people($project_id)
{
	global $db;
	global $HTTP_POST_VARS;
	
	$post_array = array();
	if (isset($HTTP_POST_VARS)) {
		$post_array = $HTTP_POST_VARS;
	} elseif(isset($_POST)) {
		$post_array = $_POST;
	}

	$sql = "DELETE FROM users_projects WHERE project_id=$project_id";
	$db->query($sql,__FILE__,__LINE__);

	foreach($post_array as $key=>$value) {
		$vars = split("_",$key);
		if ($vars[0] == "assigned") {
			$user_id = $vars[1];
			if ($user_id && is_numeric($user_id)) {
				$permissions = 0;
				if (isset($post_array["steps_" . $user_id]) && $post_array["steps_" . $user_id]) {
					$permissions += CHANGE_PERM;
				}
				$sql = "INSERT INTO users_projects (user_id,project_id,permissions) VALUES (";
				$sql.= "$user_id,$project_id, $permissions)";
				$db->query($sql,__FILE__,__LINE__);
			}
		}
	}
}
?>