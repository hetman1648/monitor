<?php

include("./includes/common.php");
include("./includes/date_functions.php");	
$user_id= GetSessionParam("UserID");		
			
$approve = GetParam("approve");
//echo $approve; 
	if (($user_id == 3) && ($approve == 1))
	{
		$period_id = GetParam("period_id");
		$sql ="UPDATE days_off SET is_approved='1' WHERE period_id='$period_id'";
		$db->query($sql);   
		header ("Location: view_vacations.php");
	}
		else if (($user_id == 3) && ($decline == 1))
		{
			$period_id = GetParam("period_id");
			$sql ="UPDATE days_off SET is_declined='1' WHERE period_id='$period_id'";
			$db->query($sql);   
			header ("Location: view_vacations.php");
	  
		}
	
			else
			{
	  		header ("Location: index.php");
			} 
?>	
				  