<?php
  include("./includes/common.php");

	if (getsessionparam("privilege_id") == 9) {
		header("Location: index.php");
		exit;
	}
	
	CheckSecurity(1);
	
	$action = GetParam("action");

	if ($action == "recalculation") {	
		CountTimeProjects();
		header("Location: users.php");
		exit;
	}

	$T = new iTemplate("./templates",array("page"=>"users.html"));

	$is_deleted = GetParam("is_deleted") ? "" : "AND is_deleted IS NULL";

	$sql  = " SELECT *,CONCAT(first_name,' ',last_name) as user_name ";
	$sql .= " FROM users AS u, lookup_users_privileges AS p ";
	$sql .= " WHERE u.privilege_id=p.privilege_id $is_deleted ";
	$sql .= " ORDER BY user_name";
	$db->query($sql);
	if($db->next_record()) {
		do {
			$T->set_var($db->Record);
			$T->parse("users_list", true);
		}
		while ($db->next_record());
	} else {
		$T->set_var("users_list", "");
	}
	
	global $number_assigned, $features_assigned;
	
	$number_assigned = array();
	$sql = "SELECT project_id, COUNT(*) as c FROM users_projects GROUP BY project_id";
	$db->query($sql);
	while ($db->next_record()){
		$number_assigned[$db->Record["project_id"]] = $db->Record["c"];
	}
  
	$features_assigned = array();
	$sql = "SELECT project_id, COUNT(*) as c FROM project_features GROUP BY project_id";
	$db->query($sql);
	while ($db->next_record()){
		 $features_assigned[$db->Record["project_id"]] = $db->Record["c"];
	}
	
  	$sql = "SELECT parent.project_id,
  				 parent.project_title,
  				 parent.project_status_id,
  				 parent.is_closed,
				 child.project_id AS c_id,
				 child.project_title AS c_title,
				 child.project_status_id AS c_status_id,
				 child.is_closed AS c_closed,				 
				 ps.color			 
		 FROM projects AS parent
		 	  LEFT JOIN projects AS child ON (parent.project_id=child.parent_project_id)
		 	  LEFT JOIN projects_statuses AS ps ON (child.project_status_id=ps.project_status_id)
		 WHERE parent.parent_project_id IS NULL
		 ORDER BY is_closed,
		 		  parent.project_title,
		 		  child.is_closed,
		 		  child.project_title ";
	$db->query($sql);
	if($db->next_record()) {
    	$lasttitle="";
	    do {
	    	$id    = $db->f("project_id");
	    	$title = $db->f("project_title");
			if ($title) {
				if ($lasttitle != $title) {
	        		parse_projects(
	        			$db->Record["project_id"],
	        			$db->Record["project_title"],
	        			$db->Record["project_status_id"],
						"0",
						$db->Record["is_closed"],
						""
					);
				}
				if ($db->Record["c_id"]) {     		
					parse_projects(
						$db->Record["c_id"],
						$db->Record["c_title"],
						$db->Record["c_status_id"],
						"16",
						$db->Record["c_closed"],
						$db->Record["color"]
					);
				}
	        	$lasttitle = $title;
	        }
		} while ($db->next_record());
	} else {
		$T->set_var("projects","");
	}

  //-- privileges
  $sql = "SELECT * FROM lookup_users_privileges ORDER BY privilege_desc";
  $db->query($sql);
  if($db->next_record())
  {
    do
    {
        $T->set_var($db->Record);
        if (isset($db->Record["user_id"]) && isset($assigned[$db->Record["user_id"]]) && $assigned[$db->Record["user_id"]])
        	$T->set_var("checked", "checked");
        else
        	$T->set_var("checked", "");
        $T->parse("privileges",true);
    }
    while ($db->next_record());
  }
  else $T->set_var("privileges","");

	$sql = "SELECT PERM_USER_PROFILE FROM lookup_users_privileges WHERE privilege_id = " . GetSessionParam("privilege_id");
	$db->query($sql);
	if ($db->next_record()) {
		$perm_user_profile = $db->f("PERM_USER_PROFILE");
	} else {
		exit($db->Error);
	}

	if (!$perm_user_profile) {
		$T->set_var("updatetimeproject", "");
	}


	$T->set_var("user_name",GetSessionParam("UserName"));
	$T->pparse("page");

	function parse_projects($id, $title, $status, $margin, $is_closed, $color) {
		global $number_assigned, $features_assigned;
		global $T;
		if (strlen($color)) {
			$T->set_var("color", $color);
		} else {
    		$T->set_var("color", "black");
		}
		if ($is_closed == 1) {
	 		$T->set_var("font","TaskOnHold");
	 		$T->set_var("color", "#D0D0D0");
	 	} else {
	 		$T->set_var("font","");
	 	}
		$T->set_var("project_title",$title);
		$T->set_var("project_id",$id);
	    $T->set_var("left_margin", $margin);
	    $T->set_var("number_assigned",(isset($number_assigned[$id]) && $number_assigned[$id]>0 ? $number_assigned[$id] : "0"));
	    $features = isset($features_assigned[$id]) && $features_assigned[$id]>0 ? $features_assigned[$id] : "0";
	    if ($features) {
	    	$T->set_var("features_assigned", $features);
	    	$T->parse("features", false);
	    } else {
	    	$T->set_var("features", "");
	    }	 
	    $T->parse("projects",true);
}

?>
