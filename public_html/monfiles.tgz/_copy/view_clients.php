<?php
	include("./includes/date_functions.php");
	include("./includes/common.php");
	include("./includes/create_table.php");
	#CheckSecurity(1);
	$T = new iTemplate($sAppPath);
	$T->set_file("main","view_clients.html");
	
	$fgoogle_id = trim(GetParam('fgoogle_id'));
	
	$T->set_var(array(	'fname'	=> GetParam('fname')?GetParam('fname'):'',
						'fmail'	=> GetParam('fmail')?GetParam('fmail'):'',
						'fsite'	=> GetParam('fsite')?GetParam('fsite'):'',
						'ftag'	=> GetParam('ftag')?GetParam('ftag'):'',
						'page'	=> GetParam('page_num')?'&page_num='.GetParam('page_num'):'',
						'fuser_id'		=> GetParam('fuser_id')?GetParam('fuser_id'):'',
						'show_table'	=> GetParam('show_table')?GetParam('show_table'):'1',
						'fcompany'		=> GetParam('fcompany')?GetParam('fcompany'):'',
						'fgoogle_id'	=> GetParam('fgoogle_id')?GetParam('fgoogle_id'):''
					));

	$sort 		= GetParam("sort");
	$reverse	= GetParam("reverse");
	if ($reverse) $T->set_var("reverse", '');
	else $T->set_var("reverse", '&reverse=reverse');
	/*if (@$_SESSION["session_perms"]['sort'] == $sort)
	{
		$reverse = true;
		$_SESSION["session_perms"]['sort'] = 'Hurrah';
	}else
	{
		$reverse = false;
		$_SESSION["session_perms"]['sort'] = $sort;
	}   */
	$type = GetParam('show_table') != '' ? GetParam('show_table') : 1;
	if ($type == 1) { $T->set_var("sayu_search","");}
	else { $T->parse("sayu_search",false);}

	$page_num = GetParam('page_num') ? GetParam('page_num') : 1;

	// SECOND DATABASE OBJECT



	$db2 = new DB_Sql;
	$db2->Database = DATABASE_NAME;
	$db2->User     = DATABASE_USER;
	$db2->Password = DATABASE_PASSWORD;
	$db2->Host     = DATABASE_HOST;
	$db2->connect();

	$sql = 'CREATE TABLE IF NOT EXISTS clients
	(
		client_id INT(11) AUTO_INCREMENT,
		PRIMARY KEY (client_id),
		sayu_user_id INT(11),
		client_name VARCHAR(255) NOT NULL,
		client_email VARCHAR(255),
		date_added DATETIME NOT NULL,
		is_viart TINYINT(2) DEFAULT \'0\',
		is_viart_hosted TINYINT(2) DEFAULT \'0\',
		notes TEXT
	)';

	$db->query($sql,__FILE__,__LINE__);

	$sql = 'SET @a := 0';

	$db->query($sql,__FILE__,__LINE__);

	$sql = '
	CREATE TABLE IF NOT EXISTS clients_sites
	(
		site_id INT(11) AUTO_INCREMENT PRIMARY KEY,
		client_id INT(11) NOT NULL,
		web_address VARCHAR(255) NOT NULL,
		admin_web_address VARCHAR(255),
		admin_web_site_login VARCHAR(40),
		admin_web_site_password VARCHAR(40),
		ftp_address VARCHAR(40),
		ftp_login VARCHAR(40),
		ftp_password VARCHAR(40),
		notes TEXT,
		date_added DATETIME NOT NULL,
		date_changed DATETIME NOT NULL
	)';
	$db->query($sql,__FILE__,__LINE__);
	$sqlsearch = '';
	if (GetParam('submit'))
	{
		if (trim(GetParam('fname')) != '') $sqlsearch .= ' AND client_name LIKE \'%'.trim(GetParam('fname')).'%\' ';
		if (trim(GetParam('fmail')) != '') $sqlsearch .= ' AND client_email LIKE \'%'.trim(GetParam('fmail')).'%\' ';
		if (trim(GetParam('fsite')) != '') $sqlsearch .= ' AND web_address LIKE \'%'.trim(GetParam('fsite')).'%\' ';
		if (trim(GetParam('fuser_id')) != '') $sqlsearch .= ' AND sayu_user_id='.ToSQL(trim(GetParam('fuser_id')), 'integer');
		if (trim(GetParam('fcompany')) != '') $sqlsearch .= ' AND client_company LIKE \'%'.trim(GetParam('fcompany')).'%\' ';
		if (trim($fgoogle_id) != '') $sqlsearch .= ' AND google_id LIKE \'%'.str_replace('-','',$fgoogle_id).'%\' ';
		if (trim(GetParam('ftag')) != '') {
			$ftag = trim(GetParam('ftag'));
			if ((strpos($ftag, '[') === 0) && (strpos($ftag, ']') === strlen($ftag) - 1)) {
				$sqlsearch .= ' AND t.title ='.ToSQL(substr($ftag, 1, strlen($ftag) - 2), "string");
			} else {
				$sqlsearch .= ' AND t.title LIKE \'%'. $ftag . '%\' ';
			}
		}
	}


	$T->set_var('tab1_class', 'close');
	$T->set_var('tab2_class', 'close');
	$T->set_var('tab3_class', 'close');



	if ($type == 1)
	{
		$sql = '

		SELECT
			IFNULL(c.sayu_user_id, \'\') as sayu_user_id,
			c.client_name as client_name,
			c.client_id as client_id,
			c.client_email as client_email,
			DATE(c.date_added) as date_added,
			IF(c.is_viart=1, \'Yes\', \'No\') as is_viart,
			IF(c.is_viart_hosted=1, \'Yes\', \'No\') as is_viart_hosted,
			REPLACE(GROUP_CONCAT(DISTINCT(cs.web_address) SEPARATOR \'<br> \'), \'http://\', \'\') as sites
		FROM (((
			clients c
			LEFT JOIN clients_sites cs ON c.client_id = cs.client_id)
			LEFT JOIN clients_sites_tags st ON st.site_id = cs.site_id)
			LEFT JOIN clients_tags t ON t.id = st.tag_id)
		WHERE client_type=1 '.$sqlsearch.'
		GROUP BY c.client_id
		';

		if (strlen($sqlsearch)) {
			CreateTable($sql, 'viart_records', 'db', 'T', $sort, $page_num, $reverse);
		} else {
			$T->set_var("pages_navigator","");
			$T->set_var("client_name","Please use filter to find a client");
			$T->set_var("client_email","");
			$T->set_var("is_viart","");
			$T->set_var("s_viart_hosted","");
			$T->set_var("sites","");
			$T->set_var("date_added","");
			$T->set_var("sayu_user_id","");
			$T->set_var("is_viart_hosted","");
		}

		$T->set_var('all_sayu_display', 'none');
		$T->set_var('sayu_display', 'none');
		$T->set_var('viart_display', '');
		$T->set_var('tab1_class', 'open');

	}

	if ($type == 2)
	{
		$sql = '
		SELECT
			c.client_id as client_id,
			IF((@a:=@a+1)%2 = 1, \'B0B0B0\', \'E0E0E0\') as color,
			c.sayu_user_id as sayu_user_id,
			IF(c.client_name<>\'\',c.client_name,\'noname\') as client_name,
			c.client_email as client_email,
			DATE(c.date_added) as date_added,
			REPLACE(GROUP_CONCAT(cs.web_address SEPARATOR \'<br>\'), \'http://\', \'\') as sites
		FROM (((
			clients c
			LEFT JOIN clients_sites cs ON c.client_id = cs.client_id)
			LEFT JOIN clients_sites_tags st ON st.site_id = cs.site_id)
			LEFT JOIN clients_tags t ON t.id = st.tag_id)
		WHERE client_type=2 AND is_active=1 '.$sqlsearch.'
		GROUP BY c.client_id
		';

		CreateTable($sql, 'sayu_records', 'db', 'T', $sort, $page_num, $reverse);
		$T->set_var('viart_display', 'none');
		$T->set_var('all_sayu_display', 'none');
		$T->set_var('sayu_display', '');
		$T->set_var('tab2_class', 'open');

	}


	if ($type == 3)
	{
		$sql = '
		SELECT
		    c.client_id as client_id,
			IF((@a:=@a+1)%2 = 1, \'B0B0B0\', \'E0E0E0\') as color,
			c.sayu_user_id as sayu_user_id,
			IF(c.client_name<>\'\',c.client_name,\'<i>noname</i>\') as client_name,
			c.client_email as client_email,
			DATE(c.date_added) as date_added,
			IF(is_active=1, \'Yes\', \'No\')as is_active,
			REPLACE(GROUP_CONCAT(cs.web_address SEPARATOR \'<br>\'), \'http://\', \'\') as sites
		FROM (((
			clients c
			LEFT JOIN clients_sites cs ON c.client_id = cs.client_id)
			LEFT JOIN clients_sites_tags st ON st.site_id = cs.site_id)
			LEFT JOIN clients_tags t ON t.id = st.tag_id)
		WHERE client_type=2 '.$sqlsearch.'
		GROUP BY c.client_id ';

		CreateTable($sql, 'all_sayu_records', 'db', 'T', $sort, $page_num, $reverse);
		$T->set_var('viart_display', 'none');
		$T->set_var('sayu_display', 'none');
		$T->set_var('all_sayu_display', '');
		$T->set_var('tab3_class', 'open');
	}

	$T->pparse("main", false);
?>