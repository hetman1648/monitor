<?php

	include("./includes/common.php");

	if (!GetSessionParam("UserID")) {
		header("Location: login.php");
		exit();
	}	

	$err		= "";
	$operation	= GetParam("operation");
	$action		= GetParam("action");
	$first_name	= GetParam("first_name");
	$last_name	= GetParam("last_name");
	$email		= GetParam("email");
	$user_id	= GetParam("user_id");
	$password	= GetParam("password");
	$login		= GetParam("login");
	$day_phone	= GetParam("day_phone");
	$evn_phone	= GetParam("evn_phone");
	$birth_date	= GetParam("birth_date")?GetParam("birth_date"):"0000-00-00";
	$start_date	= GetParam("start_date")?GetParam("start_date"):date("Y-m-d");
	$address	= GetParam("address");
	$cvs_login	= GetParam("cvs_login");	
	$is_viart	= GetParam("is_viart");
	$ticket_tasks = GetParam("ticket_tasks");
	$office_id	= GetParam("office_id");
	$is_sms		= GetParam("is_sms");
	$cell_phone	= GetParam("cell_phone");
	$manager_id	= GetParam("manager_list");
	$is_flexible		= GetParam("is_flexible");
	$privilege_group	= GetParam("privilege_group");
	$msn_account		= GetParam("msn_account");
	$sms_account		= GetParam("sms_account");
	$skype_account		= GetParam("skype_account");
	$svn_login          = GetParam("svn_login");
	$svn_password       = GetParam("svn_password");
	$web_clients_resource = GetParam("web_clients_resource");
	$helpdesk_user_id	= GetParam("helpdesk_user_id");
	$team_name			= GetParam("team_name");
	$show_users_list		= GetParam("show_users_list");
	$show_projects_list		= GetParam("show_projects_list");
	$is_cvs_notification    = GetParam("is_cvs_notification");
	
	$team_id = 0;

	if ($action == "self") {
		if ($operation == "submit") {
			if (!$first_name)	$err .= "<b>First Name</b> is required<br>";
			if (!$last_name)	$err .= "<b>Last Name</b> is required<br>";
			if (!$email)		$err .= "<b>E-mail</b> is required<br>";
			if (!$err) {

				$sql = "UPDATE users
						SET email		=".ToSQL($email,"string").",
							first_name	=".ToSQL($first_name,"string").",
							last_name	=".ToSQL($last_name,"string").",
							day_phone	=".ToSQL($day_phone,"string").",
							evn_phone	=".ToSQL($evn_phone,"string").",
							cell_phone	=".ToSQL($cell_phone,"string").",
							msn_account	=".ToSQL($msn_account,"string").",
							sms_account	=".ToSQL($sms_account,"string").",
							skype_account=".ToSQL($skype_account,"string").",
							svn_login   =".ToSQL($svn_login,"string").",
							svn_password=".ToSQL($svn_password,"string").",
							web_clients_resource=".ToSQL(web_clients_resource,"integer").",
							birth_date	=".ToSQL($birth_date,"date").",
							start_date	=".(ToSQL($start_date,"date")=="0000-00-00"?"'".date("Y-m-d")."'":ToSQL($start_date,"date")).",
							address		=".ToSQL($address,"string").",
							show_users_list	=".ToSQL($show_users_list,"integer",false).",
							show_projects_list	=".ToSQL($show_projects_list,"integer",false).",
							cvs_login =".ToSQL($cvs_login,"string")."
						WHERE user_id= " . GetSessionParam("UserID");
				 $db->query($sql,__FILE__,__LINE__);
			header("Location: index.php");
			exit;
			}
		}

		//  if (GetSessionParam("privilege_id") == 7)
		$T = new iTemplate("./templates", array("page"=>"user_profile.html"));
		if ($err) $T->set_var("err", $err); else $T->set_var("error", "");

		$sql = " SELECT * FROM users WHERE user_id=" . GetSessionParam("UserID");
		$db->query($sql,__FILE__,__LINE__);
		if($db->next_record()) {
			$T->set_var($db->Record);
		}

		$T->set_var("user_name", GetSessionParam("UserName"));
		$T->set_var("user_id", $user_id);
		$T->set_var("params", "?action=self");
		$T->set_var("control", "");
		$T->set_var("delete", "");
		
				if ($db->f("show_users_list")) {
					$T->set_var("show_users_list_checked", "checked");
				} else {
					$T->set_var("show_users_list_checked", "");
				}
								
				if ($db->f("show_projects_list")) {
					$T->set_var("show_projects_list_checked", "checked");
				} else {
					$T->set_var("show_projects_list_checked", "");
				}		

		//disable editing start_date and hide calendar
		$T->set_var("is_disabled"," readonly");
		$T->set_var("display_start_calendar","none");

		$T->pparse("page");
	} else {
		
		$sql = "SELECT PERM_USER_PROFILE FROM lookup_users_privileges WHERE privilege_id = " . GetSessionParam("privilege_id");
		$db->query($sql,__FILE__,__LINE__);
		if ($db->next_record()) {
			$perm_user_profile = $db->f("PERM_USER_PROFILE");
		} else {
			exit($db->Error);
		}

		if (!$perm_user_profile) {
			exit("You don't have permission for this!");
		}

		$err = "";

		if ($operation == "delete" && $user_id) {
			$sql = "UPDATE users SET is_deleted=1 WHERE user_id=$user_id";
			$db->query($sql,__FILE__,__LINE__);
			header("Location: users.php");
			exit;
		}

		if ($operation == "undelete" && $user_id) {
			$sql = "UPDATE users SET is_deleted=Null WHERE user_id=$user_id";
			$db->query($sql,__FILE__,__LINE__);
			header("Location: users.php");
			exit;
		}

		if ($operation == "submit") {
			if (!$login)			{ $err .= "<b>Login</b> is required<br>";}
			if (!$password)			{ $err .= "<b>Password</b> is required<br>";}
			if (!$first_name)		{ $err .= "<b>First Name</b> is required<br>";}
			if (!$last_name)		{ $err .= "<b>Last Name</b> is required<br>";}
			if (!$privilege_group)	{ $err .= "<b>Privilege Group</b> is required<br>";}
			if (!$err) {
				
				$is_viart            = ($is_viart) ? 1 : 0;				
				$is_sms              = ($is_sms) ? 1 : 0;
				$is_cvs_notification = ($is_cvs_notification) ? 1 : 0;
				$is_flexible         = ($is_flexible) ? 1 : 0;
				$ticket_tasks        = ($ticket_tasks) ? 1 : 0;
				$show_users_list     = ($show_users_list) ? 1 : 0;
				$show_projects_list  = ($show_projects_list) ? 1 : 0;
								
				if ($privilege_group == 3 && (!$manager_id || $manager_id == -1) || $user_id == $manager_id) {$manager_id = 0;}

				if ($user_id) {
					$sql = "UPDATE users
							SET	login		=".ToSQL($login,"string").",
								password	=".ToSQL($password,"string").",
								email		=".ToSQL($email,"string").",
								first_name	=".ToSQL($first_name,"string").",
								last_name	=".ToSQL($last_name,"string").",
								day_phone	=".ToSQL($day_phone,"string").",
								evn_phone	=".ToSQL($evn_phone,"string").",
								cell_phone	=".ToSQL($cell_phone,"string").",
								msn_account	=".ToSQL($msn_account,"string").",
								sms_account	=".ToSQL($sms_account,"string").",
								skype_account=".ToSQL($skype_account,"string").",
								svn_login   =".ToSQL($svn_login,"string").",
								svn_password=".ToSQL($svn_password,"string").",
								web_clients_resource=".ToSQL($web_clients_resource,"integer").",								
								birth_date	=".ToSQL($birth_date,"date").",
								start_date	=".(ToSQL($start_date,"date")=="0000-00-00"?"'".date("Y-m-d")."'":ToSQL($start_date,"date")).",
								address		=".ToSQL($address,"string").",
								cvs_login   =".ToSQL($cvs_login,"string").",
								privilege_id=".ToSQL($privilege_group,"integer",false).",
								office_id	=".ToSQL($office_id,"integer", false).",
								is_viart	=".ToSQL($is_viart,"integer",false).",
								is_send_sms	=".ToSQL($is_sms,"integer",false).",
								is_cvs_notification	=".ToSQL($is_cvs_notification,"integer",false).",				
								is_flexible	=".ToSQL($is_flexible,"integer",false).",
								ticket_tasks =".ToSQL($ticket_tasks,"integer",false).",
								manager_id	=".ToSQL($manager_id,"integer",false).",
								show_users_list	=".ToSQL($show_users_list,"integer",false).",
								show_projects_list	=".ToSQL($show_projects_list,"integer",false).",
								helpdesk_user_id =".ToSQL($helpdesk_user_id,"integer")."
							WHERE user_id=".ToSQL($user_id,"integer",false);
					 $db->query($sql,__FILE__,__LINE__);
				} else {
					$sql = " INSERT INTO users (login, password, email, first_name, last_name, day_phone, evn_phone, cell_phone, ";
					$sql.= " msn_account, sms_account, skype_account,svn_login,svn_password, birth_date, start_date, address, cvs_login, privilege_id, office_id, is_viart, is_send_sms, is_cvs_notification, ";
					$sql.= " is_flexible,ticket_tasks,manager_id,helpdesk_user_id,show_users_list,show_projects_list)
							VALUES(	".ToSQL($login,"string").",
									".ToSQL($password,"string").",
									".ToSQL($email,"string").",
									".ToSQL($first_name,"string").",
									".ToSQL($last_name,"string").",
									".ToSQL($day_phone,"string").",
									".ToSQL($evn_phone,"string").",
									".ToSQL($cell_phone,"string").",
									".ToSQL($msn_account,"string").",
									".ToSQL($sms_account,"string").",
									".ToSQL($skype_account,"string").",
									".ToSQL($svn_login,"string").",
									".ToSQL($svn_password,"string").",
									".ToSQL($web_clients_resource,"integer").",									
									".ToSQL($birth_date,"date").",
									".(ToSQL($start_date,"date")=="0000-00-00"?"'".date("Y-m-d")."'":ToSQL($start_date,"date")).",
									".ToSQL($address,"string").",
									".ToSQL($cvs_login,"string").",
									".ToSQL($privilege_group,"integer",false).",
									".ToSQL($office_id,"integer").",
									".ToSQL($is_viart,"integer",false).",
									".ToSQL($is_sms,"integer",false).",
									".ToSQL($is_cvs_notification,"integer",false).",
									
									".ToSQL($is_flexible,"integer",false).",
									".ToSQL($ticket_tasks,"integer",false).",
									".ToSQL($manager_id,"integer",false).",
									".ToSQL($helpdesk_user_id,"integer").",
									".ToSQL($show_users_list,"integer", false).",
									".ToSQL($show_projects_list,"integer", false).")";
					$db->query($sql);
					if ($is_viart) {
						$sql = "SELECT LAST_INSERT_ID()";
						$db->query($sql,__FILE__,__LINE__);
						if ($db->next_record()) { $user_id = $db->f(0);}
						if ($user_id>0) {
							$sql = "INSERT INTO lunches_allocated_people VALUES (".ToSQL($user_id,"integer",false).", 1, NULL)";
							$db->query($sql,__FILE__,__LINE__);
						}
					}
				}
				if ($privilege_group == PRIV_PM && strlen(trim($team_name))) {
					$sql  = " SELECT * FROM users_teams WHERE team_name like " . ToSQL(trim($team_name),"string");
					//$sql .= " AND manager_id =" . ToSQL($user_id,"integer",false);
					$db->query($sql,__FILE__,__LINE__);
					if ($db->next_record()) {
						$team_id = $db->f("team_id");
						$temp_manager_id = $db->f("manager_id");
						if ($user_id != $temp_manager_id) {
							$sql  = " UPDATE users_teams SET manager_id = 0 WHERE manager_id =" . ToSQL($user_id,"integer",false);
							$db->query($sql,__FILE__,__LINE__);
							$sql  = " UPDATE users_teams SET manager_id =" . ToSQL($user_id,"integer",false);
							$sql .= " WHERE team_id = " . ToSQL($team_id,"integer",false);
							$db->query($sql,__FILE__,__LINE__);
						}
					} else {
						$sql  = " UPDATE users_teams SET manager_id = 0 WHERE manager_id =" . ToSQL($user_id,"integer",false);
						$db->query($sql,__FILE__,__LINE__);
						$sql  = " INSERT INTO users_teams(team_name,manager_id) ";
						$sql .= " VALUES(" . ToSQL(trim($team_name),"string") . ", " . ToSQL($user_id,"integer",false) .")";
						$db->query($sql,__FILE__,__LINE__);
						$sql = " SELECT LAST_INSERT_ID();";
						$db->query($sql,__FILE__,__LINE__);
						$team_id = $db->f(0);
					}
				}
				//header("Location: users.php");
				//exit;
			}
		}

		//  if (GetSessionParam("privilege_id") == 7)
		$T = new iTemplate("./templates",array("page"=>"user_profile.html"));
		$T->set_var("err",$err);

		//-- user details
		$T->set_var(array(
			"first_name"  => $first_name,
			"last_name"   => $last_name,
			"email"       => $email,
		  	"day_phone"   => $day_phone,
			"evn_phone"   => $evn_phone,
			"cell_phone"  => $evn_phone,
			"msn_account" => $msn_account,
			"sms_account" => $sms_account,
			"skype_account" => $skype_account,
			"svn_login"   => $svn_login,
			"svn_password"=> $svn_password,
			"web_clients_resource" => $web_clients_resource,
			"birth_date"  => $birth_date,
			"start_date"  => $start_date,
			"address"     => $address,
			"cvs_login"   => $cvs_login,
			"login"       => $login,
			"password"    => $password,
			"helpdesk_user_id" => $helpdesk_user_id
			));

		$isdelete = "";

		if ($user_id && is_number($user_id)) {
			//$sql = "SELECT *, CONCAT(first_name,' ',last_name) as user_name FROM users WHERE user_id=".ToSQL($user_id,"integer",false);
			$sql  = " SELECT *, CONCAT(u.first_name,' ',u.last_name) as user_name ";
			$sql .= " FROM users u ";
			$sql .= " LEFT JOIN users_teams ut ON (IF(u.manager_id>0,u.manager_id,user_id) = ut.manager_id)";
			$sql .= " WHERE user_id=".ToSQL($user_id,"integer",false);
			$db->query($sql,__FILE__,__LINE__);
			if($db->next_record()) {
				$T->set_var($db->Record);

				if ($db->f("is_viart")) {
					$T->set_var("viart_checked", "checked");
				} else {
					$T->set_var("viart_checked", "");
				}				

				if ($db->f("is_flexible")) {
					$T->set_var("flexible_checked", "checked");
				} else {
					$T->set_var("flexible_checked", "");
				}
				
				if ($db->f("is_cvs_notification")) {
					$T->set_var("cvs_notification_checked", "checked");
				} else {
					$T->set_var("cvs_notification_checked", "");
				}

				if ($db->f("ticket_tasks")) {
					$T->set_var("ticket_tasks_checked", "checked");
				} else {
					$T->set_var("ticket_tasks_checked", "");
				}
				
				if ($db->f("is_send_sms")) {
					$T->set_var("sms_checked", "checked");
				} else {
					$T->set_var("sms_checked", "");
				}
				
				if ($db->f("is_cvs_notification")) {
					$T->set_var("is_cvs_notification", "checked");
				} else {
					$T->set_var("is_cvs_notification", "");
				}
				
				if ($db->f("show_users_list")) {
					$T->set_var("show_users_list_checked", "checked");
				} else {
					$T->set_var("show_users_list_checked", "");
				}

				if ($db->f("show_projects_list")) {
					$T->set_var("show_projects_list_checked", "checked");
				} else {
					$T->set_var("show_projects_list_checked", "");
				}
				
				if ($db->f("helpdesk_user_id")) {
					$T->set_var("helpdesk_user_id", $db->f("helpdesk_user_id"));
				} else {
					$T->set_var("helpdesk_user_id", "");
				}				

				if (!$db->Record["is_deleted"]) {
					$isdelete = "<input type=\"button\" value=\"Delete\" onClick=\"deleteUser()\">";
				} else {
					$isdelete = "<input type=\"button\" value=\"UnDelete\" onClick=\"UnDeleteUser()\">";
				}

		  		if ($db->f("privilege_id") != PRIV_PM) {
					$T->set_var("is_readonly","READONLY");
				}
				$is_viart = $db->f("is_viart");
		  		$privilege_group = $db->Record["privilege_id"];
		  		$office_id = $db->Record["office_id"];
		  		$manager_id = $db->f("manager_id");
				$team_id = $db->f("team_id");
			}
		}
		
		$T->set_var("team_id",$team_id);
		
		$T->set_var("team_name","");
		$T->set_var("TeamArray","");
		$sql = "SELECT * FROM users_teams";
		$db->query($sql,__FILE__,__LINE__);
		while ($db->next_record()) {
			$team_manager_id = $db->f("manager_id");
			$team_name = $db->f("team_name");
			$T->set_var("ManagerID",$team_manager_id);
			$T->set_var("teams_name",$team_name);
			$T->parse("TeamArray",true);
			if ($team_id == $db->f("team_id")) {
				$T->set_var("team_name",$team_name);
			}
		}

		$T->set_var("buttondelete",$isdelete);

		$T->set_var("privileges",get_options("lookup_users_privileges","privilege_id","privilege_desc",$privilege_group,""));
		$T->set_var("offices",get_options("offices","office_id","office_title",$office_id,""));
		$T->set_var("manager_list",get_options("users WHERE is_deleted IS NULL AND privilege_id=4 AND is_viart=".ToSQL($is_viart,"integer",false),"user_id","CONCAT(first_name,' ', last_name)",($manager_id?$manager_id:-1),""));
		$T->set_var("user_name",GetSessionParam("UserName"));
		$T->set_var("error", "");
		if ($user_id) {
			$T->set_var("params", "?user_id=" . $user_id);
		} else {
			$T->set_var("params", "");
		}

		//show calendar (eq style.display)
		$T->set_var("display_start_calendar","");

		$sql = "SELECT user_id, is_viart, CONCAT(first_name,' ', last_name) as person FROM users u WHERE is_deleted IS NULL AND privilege_id=4 ORDER BY person";
		$db->query($sql,__FILE__,__LINE__);
		$id=0;
		while ($db->next_record())
		{
			$T->set_var("ID",(int)$id++);
			$T->set_var("IDteam",(int)$db->f("is_viart"));
			$T->set_var("IDuser",(int)$db->f("user_id"));
			$T->set_var("user_name",$db->f("person"));
			$T->parse("PeopleArray",true);
		}

		$T->pparse("page");
	}

?>